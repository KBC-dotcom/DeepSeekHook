# Xposed 入口类与 Hook 回调不能被混淆/移除
-keep class com.hook.deepseek.ModuleEntry { *; }
-keep class com.hook.deepseek.xapi.** { *; }
-keepclassmembers class * {
    @androidx.annotation.Keep <methods>;
}
-keepattributes *Annotation*
