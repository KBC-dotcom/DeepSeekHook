package com.hook.deepseek.core.config

import org.json.JSONArray
import org.json.JSONObject

/** 一个可插拔的变换器配置 */
data class TransformerSpec(
    val id: String,
    val enabled: Boolean = true,
    val params: Map<String, String> = emptyMap()
)

/** 隐藏 / 伪装相关配置 */
data class ConcealConfig(
    val enabled: Boolean = true,
    /** 包管理器枚举过滤（LSPosed / KSU / Magisk / SuperSU ...） */
    val hideRootPackages: Boolean = true,
    /** 屏蔽目标进程里对 Xposed / LSPosed 类的加载 */
    val hideXposedClasses: Boolean = true,
    /** 覆盖 android.os.Build 静态字段 */
    val spoofBuild: Boolean = true,
    /** 覆盖 SystemProperties.get */
    val spoofSystemProperties: Boolean = true,
    /** 覆盖 Os.uname() */
    val spoofUname: Boolean = true,
    /** 追加屏蔽的包名，逗号分隔 */
    val extraBlockedPackages: String = ""
)

/**
 * 模块总配置。
 * 由模块 App 写入，通过 ContentProvider 提供给目标进程读取。
 */
data class HookConfig(
    val enabled: Boolean = true,
    /** 绕过 OkHttp CertificatePinner */
    val bypassPinning: Boolean = true,
    /** 同时放宽 hostname 校验（默认关闭，影响面更大） */
    val bypassHostnameVerifier: Boolean = false,
    /** 改写请求体 */
    val rewriteRequest: Boolean = true,
    /** 改写响应体 */
    val rewriteResponse: Boolean = false,
    /** 单次改写的最大字节数 */
    val maxRewriteBytes: Int = 2 * 1024 * 1024,
    /** 允许改写的 Content-Type 子串过滤，逗号分隔；!xxx 表示排除；* 表示全部 */
    val contentTypeFilter: String = "json",
    val transformers: List<TransformerSpec> = DEFAULT_TRANSFORMERS,
    val conceal: ConcealConfig = ConcealConfig(),
    val debugLog: Boolean = false,
    /** 日志脱敏：只记录长度与摘要，不记录正文 */
    val redactLog: Boolean = true
) {

    /**
     * 判断某个 Content-Type 是否允许进入改写流程。
     */
    fun matchesContentType(contentType: String?): Boolean {
        if (contentType.isNullOrBlank()) return false
        val rules = contentTypeFilter.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (rules.isEmpty()) return true
        val ct = contentType.lowercase()
        var hasPositive = false
        var positiveHit = false
        for (r in rules) {
            if (r.startsWith("!")) {
                if (ct.contains(r.substring(1).trim())) return false
            } else {
                hasPositive = true
                if (r == "*" || ct.contains(r)) positiveHit = true
            }
        }
        return if (hasPositive) positiveHit else true
    }

    companion object {
        val DEFAULT_TRANSFORMERS: List<TransformerSpec> = listOf(
            TransformerSpec("whitespace"),
            TransformerSpec("terminology", params = mapOf("pairs" to "")),
            TransformerSpec("prefix", params = mapOf("template" to "", "trigger" to "", "scope" to "last"))
        )
    }
}

/**
 * 配置的 JSON 序列化 / 反序列化。
 * 使用 framework 自带的 org.json，不引入任何第三方依赖。
 */
object ConfigJson {

    fun toJson(cfg: HookConfig): String {
        val root = JSONObject()
        root.put("enabled", cfg.enabled)
        root.put("bypassPinning", cfg.bypassPinning)
        root.put("bypassHostnameVerifier", cfg.bypassHostnameVerifier)
        root.put("rewriteRequest", cfg.rewriteRequest)
        root.put("rewriteResponse", cfg.rewriteResponse)
        root.put("maxRewriteBytes", cfg.maxRewriteBytes)
        root.put("contentTypeFilter", cfg.contentTypeFilter)
        root.put("debugLog", cfg.debugLog)
        root.put("redactLog", cfg.redactLog)

        val c = JSONObject()
        c.put("enabled", cfg.conceal.enabled)
        c.put("hideRootPackages", cfg.conceal.hideRootPackages)
        c.put("hideXposedClasses", cfg.conceal.hideXposedClasses)
        c.put("spoofBuild", cfg.conceal.spoofBuild)
        c.put("spoofSystemProperties", cfg.conceal.spoofSystemProperties)
        c.put("spoofUname", cfg.conceal.spoofUname)
        c.put("extraBlockedPackages", cfg.conceal.extraBlockedPackages)
        root.put("conceal", c)

        val arr = JSONArray()
        for (t in cfg.transformers) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("enabled", t.enabled)
            val p = JSONObject()
            for ((k, v) in t.params) p.put(k, v)
            o.put("params", p)
            arr.put(o)
        }
        root.put("transformers", arr)
        return root.toString()
    }

    fun fromJson(text: String?): HookConfig {
        val def = HookConfig()
        if (text.isNullOrBlank()) return def
        return try {
            val root = JSONObject(text)
            val conceal = root.optJSONObject("conceal")
            val transformers = ArrayList<TransformerSpec>()
            val arr = root.optJSONArray("transformers")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val params = HashMap<String, String>()
                    val p = o.optJSONObject("params")
                    if (p != null) {
                        val keys = p.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            params[k] = p.optString(k, "")
                        }
                    }
                    transformers.add(
                        TransformerSpec(
                            id = o.optString("id", "whitespace"),
                            enabled = o.optBoolean("enabled", true),
                            params = params
                        )
                    )
                }
            }
            HookConfig(
                enabled = root.optBoolean("enabled", def.enabled),
                bypassPinning = root.optBoolean("bypassPinning", def.bypassPinning),
                bypassHostnameVerifier = root.optBoolean("bypassHostnameVerifier", def.bypassHostnameVerifier),
                rewriteRequest = root.optBoolean("rewriteRequest", def.rewriteRequest),
                rewriteResponse = root.optBoolean("rewriteResponse", def.rewriteResponse),
                maxRewriteBytes = root.optInt("maxRewriteBytes", def.maxRewriteBytes),
                contentTypeFilter = root.optString("contentTypeFilter", def.contentTypeFilter),
                transformers = if (transformers.isEmpty()) def.transformers else transformers,
                conceal = ConcealConfig(
                    enabled = conceal?.optBoolean("enabled", def.conceal.enabled) ?: def.conceal.enabled,
                    hideRootPackages = conceal?.optBoolean("hideRootPackages", def.conceal.hideRootPackages) ?: def.conceal.hideRootPackages,
                    hideXposedClasses = conceal?.optBoolean("hideXposedClasses", def.conceal.hideXposedClasses) ?: def.conceal.hideXposedClasses,
                    spoofBuild = conceal?.optBoolean("spoofBuild", def.conceal.spoofBuild) ?: def.conceal.spoofBuild,
                    spoofSystemProperties = conceal?.optBoolean("spoofSystemProperties", def.conceal.spoofSystemProperties) ?: def.conceal.spoofSystemProperties,
                    spoofUname = conceal?.optBoolean("spoofUname", def.conceal.spoofUname) ?: def.conceal.spoofUname,
                    extraBlockedPackages = conceal?.optString("extraBlockedPackages", def.conceal.extraBlockedPackages) ?: def.conceal.extraBlockedPackages
                ),
                debugLog = root.optBoolean("debugLog", def.debugLog),
                redactLog = root.optBoolean("redactLog", def.redactLog)
            )
        } catch (t: Throwable) {
            def
        }
    }
}
