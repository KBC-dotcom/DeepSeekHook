package com.hook.deepseek.engine.util

import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 单线程后台队列。
 *
 * 用途：日志落盘、配置刷新、以及可选的响应预取。
 * 绝不在这里做会阻塞 OkHttp Dispatcher 网络线程的事情。
 */
object Worker {

    private val stopped = AtomicBoolean(false)

    private val executor = Executors.newSingleThreadExecutor(ThreadFactory { r ->
        Thread(r, "dsh-worker").apply {
            isDaemon = true
            priority = Thread.MIN_PRIORITY
        }
    })

    fun submit(task: () -> Unit) {
        if (stopped.get()) return
        try {
            executor.execute {
                try {
                    task()
                } catch (t: Throwable) {
                    DshLog.e("worker task failed", t)
                }
            }
        } catch (t: Throwable) {
            // 线程池已关闭等情况，忽略
        }
    }

    fun shutdown() {
        if (stopped.compareAndSet(false, true)) {
            try {
                executor.shutdownNow()
            } catch (t: Throwable) {
            }
        }
    }
}
