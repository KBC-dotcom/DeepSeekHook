package com.hook.deepseek.engine.util

import android.content.Context

/**
 * 拿到目标进程（DeepSeek）的 Context。
 * 全部走反射，避免依赖 hidden API 的编译期可见性。
 */
object AppContext {

    @Volatile
    private var cached: Context? = null

    fun current(): Context? {
        cached?.let { return it }
        val c = fromAndroidAppHelper() ?: fromActivityThread()
        if (c != null) cached = c
        return c
    }

    private fun fromAndroidAppHelper(): Context? = try {
        val clazz = Class.forName("android.app.AndroidAppHelper")
        clazz.getMethod("currentApplication").invoke(null) as? Context
    } catch (t: Throwable) {
        null
    }

    private fun fromActivityThread(): Context? = try {
        val clazz = Class.forName("android.app.ActivityThread")
        clazz.getMethod("currentApplication").invoke(null) as? Context
    } catch (t: Throwable) {
        null
    }
}
