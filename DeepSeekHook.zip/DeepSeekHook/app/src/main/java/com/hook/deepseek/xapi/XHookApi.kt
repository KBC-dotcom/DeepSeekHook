package com.hook.deepseek.xapi

import java.lang.reflect.Member
import java.lang.reflect.Method

/**
 * 统一的 Hook 回调参数视图。
 *
 * 之所以要抽象这一层：legacy（de.robv.android.xposed）与 modern（io.github.libxposed.api）
 * 两套 API 的回调签名、结果回写方式完全不同。业务代码只面向本类编程，
 * 换 API 时只需要改 src/legacy 与 src/modern 两个目录下的适配器。
 */
class XParam(
    /** 被 Hook 的成员（方法或构造器） */
    val member: Member,
    /** 实例方法的 this；静态方法为 null */
    val thisObject: Any?,
    /** 实参数组；注意是活数组，修改元素会直接影响真实调用 */
    val args: Array<Any?>?,
    /** true 表示 before 阶段，false 表示 after 阶段 */
    val before: Boolean,
    initialResult: Any? = null,
    initialThrowable: Throwable? = null
) {

    var result: Any? = initialResult
        private set

    var throwable: Throwable? = initialThrowable
        private set

    private var resultSet = false

    /** 显式设置返回值（before 阶段设置则原方法不再执行） */
    fun setResult(value: Any?) {
        result = value
        resultSet = true
    }

    /** 是否被显式改写过结果 */
    fun isResultSet(): Boolean = resultSet

    fun setThrowable(t: Throwable?) {
        throwable = t
    }

    fun arg(index: Int): Any? = args?.getOrNull(index)

    fun setArg(index: Int, value: Any?) {
        args?.set(index, value)
    }
}

/**
 * Xposed 能力的最小抽象。
 *
 * 约定：
 *  - before 回调里若调用 setResult()，原方法被短路，直接返回该结果；
 *  - after 回调里若调用 setResult()，结果覆盖原方法返回值；
 *  - 任何回调抛出的异常都应被业务层自行 catch（protective 语义）。
 */
interface XHookApi {

    fun findClass(name: String, cl: ClassLoader? = null): Class<*>?

    /** Hook 目标类的所有同名方法（含重载）。返回成功 Hook 的个数。 */
    fun hookAllMethods(
        clazz: Class<*>,
        name: String,
        before: ((XParam) -> Unit)? = null,
        after: ((XParam) -> Unit)? = null
    ): Int

    /** Hook 目标类的所有构造器。 */
    fun hookAllConstructors(
        clazz: Class<*>,
        before: ((XParam) -> Unit)? = null,
        after: ((XParam) -> Unit)? = null
    ): Int

    fun hookMethod(
        method: Method,
        before: ((XParam) -> Unit)? = null,
        after: ((XParam) -> Unit)? = null
    ): Boolean

    /** 写静态字段（用于 Build.* 伪装）。失败返回 false（Android 12+ 部分 final 字段受保护）。 */
    fun setStaticObjectField(clazz: Class<*>, name: String, value: Any?): Boolean

    fun log(message: String)

    fun logError(message: String, t: Throwable)
}
