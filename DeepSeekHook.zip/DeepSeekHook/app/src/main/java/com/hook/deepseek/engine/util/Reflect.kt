package com.hook.deepseek.engine.util

import java.lang.reflect.Field
import java.lang.reflect.Method
import java.lang.reflect.Modifier

/** 反射小工具：全部失败返回 null / false，不抛异常（protective 语义）。 */
object Reflect {

    fun method(clazz: Class<*>, name: String, vararg types: Class<*>): Method? = try {
        clazz.getDeclaredMethod(name, *types)
    } catch (t: Throwable) {
        null
    }

    fun publicMethod(clazz: Class<*>, name: String, vararg types: Class<*>): Method? = try {
        clazz.getMethod(name, *types)
    } catch (t: Throwable) {
        null
    }

    fun field(clazz: Class<*>, name: String): Field? = try {
        clazz.getDeclaredField(name).also { it.isAccessible = true }
    } catch (t: Throwable) {
        null
    }

    fun readField(target: Any, name: String): Any? = try {
        field(target.javaClass, name)?.get(target)
    } catch (t: Throwable) {
        null
    }

    /** 写实例字段（ART 上 setAccessible 后允许写 final 实例字段）。 */
    fun writeField(target: Any, name: String, value: Any?): Boolean = try {
        val f = field(target.javaClass, name) ?: return false
        f.set(target, value)
        true
    } catch (t: Throwable) {
        false
    }

    fun readStatic(clazz: Class<*>, name: String): Any? = try {
        field(clazz, name)?.get(null)
    } catch (t: Throwable) {
        null
    }

    fun writeStatic(clazz: Class<*>, name: String, value: Any?): Boolean = try {
        val f = field(clazz, name) ?: return false
        f.set(null, value)
        true
    } catch (t: Throwable) {
        false
    }

    fun newInstance(clazz: Class<*>): Any? = try {
        val c = clazz.getDeclaredConstructor()
        c.isAccessible = true
        c.newInstance()
    } catch (t: Throwable) {
        null
    }

    /** 找同名静态方法（参数个数一致即可，具体类型在调用处校验）。 */
    fun staticMethod(clazz: Class<*>, name: String, argCount: Int): Method? = try {
        clazz.methods.firstOrNull {
            it.name == name && Modifier.isStatic(it.modifiers) && it.parameterTypes.size == argCount
        }
    } catch (t: Throwable) {
        null
    }
}
