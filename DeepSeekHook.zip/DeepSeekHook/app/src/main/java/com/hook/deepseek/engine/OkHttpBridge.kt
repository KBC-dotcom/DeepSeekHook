package com.hook.deepseek.engine

import com.hook.deepseek.engine.util.Reflect
import java.lang.reflect.Method
import java.lang.reflect.Modifier

/**
 * 反射式 OkHttp / Okio 访问层。
 *
 * 关键约束：模块 APK 会被注入到目标进程，如果把 okhttp 打进 APK，
 * 会与目标 App 自带的 okhttp 产生类加载冲突（尤其是 OkHttp 4.x 的
 * okhttp3.internal.* 包名）。因此本工程不依赖任何 okhttp 制品，
 * 全部通过反射访问目标进程里的类。
 *
 * 兼容性：同时适配 OkHttp 3.x / 4.x / 5.x 的命名与签名差异。
 */
class OkHttpBridge(val cl: ClassLoader) {

    val requestClass: Class<*>? = load("okhttp3.Request")
    val requestBuilderClass: Class<*>? = load("okhttp3.Request\$Builder")
    val requestBodyClass: Class<*>? = load("okhttp3.RequestBody")
    val responseBodyClass: Class<*>? = load("okhttp3.ResponseBody")
    val responseClass: Class<*>? = load("okhttp3.Response")
    val mediaTypeClass: Class<*>? = load("okhttp3.MediaType")

    val bufferClass: Class<*>? = load("okio.Buffer")
    val bufferedSourceClass: Class<*>? = load("okio.BufferedSource")
    val bufferedSinkClass: Class<*>? = load("okio.BufferedSink")
    val byteStringClass: Class<*>? = load("okio.ByteString")

    /** OkHttp 3.x 是 okhttp3.internal.http.RealResponseBody，4.x 是 okhttp3.internal.http.RealResponseBody */
    val realResponseBodyClass: Class<*>? = loadFirst(
        "okhttp3.internal.http.RealResponseBody",
        "okhttp3.RealResponseBody"
    )

    val realInterceptorChainClass: Class<*>? = loadFirst(
        "okhttp3.internal.http.RealInterceptorChain",
        "okhttp3.RealInterceptorChain"
    )

    val certificatePinnerClass: Class<*>? = load("okhttp3.CertificatePinner")
    val okHostnameVerifierClass: Class<*>? = loadFirst(
        "okhttp3.internal.tls.OkHostnameVerifier",
        "okhttp3.OkHostnameVerifier"
    )

    val ok: Boolean =
        requestClass != null && requestBuilderClass != null && requestBodyClass != null &&
            responseBodyClass != null && bufferClass != null

    private fun load(name: String): Class<*>? = try {
        cl.loadClass(name)
    } catch (t: Throwable) {
        null
    }

    private fun loadFirst(vararg names: String): Class<*>? {
        for (n in names) {
            val c = load(n)
            if (c != null) return c
        }
        return null
    }

    // ------------------------------------------------------------------ Request

    fun requestBody(request: Any): Any? = try {
        request.javaClass.getMethod("body").invoke(request)
    } catch (t: Throwable) {
        null
    }

    fun requestMethod(request: Any): String? = try {
        request.javaClass.getMethod("method").invoke(request) as? String
    } catch (t: Throwable) {
        null
    }

    /** 是否已经被本模块改写过（用 Request.tag 打标记） */
    fun isMarked(request: Any): Boolean = try {
        val m = request.javaClass.getMethod("tag", Class::class.java)
        m.invoke(request, RewriteMarker::class.java) != null
    } catch (t: Throwable) {
        false
    }

    /** 给 Request 打上「已改写」标记 */
    fun markRequest(request: Any): Any? = try {
        val nb = request.javaClass.getMethod("newBuilder").invoke(request) ?: return null
        val m = nb.javaClass.getMethod("tag", Class::class.java, Object::class.java)
        m.invoke(nb, RewriteMarker::class.java, RewriteMarker)
        nb.javaClass.getMethod("build").invoke(nb)
    } catch (t: Throwable) {
        null
    }

    /** 用新的 body 重建一个 Request（保持 url / headers / tags 不变） */
    fun rebuildRequest(request: Any, newBody: Any): Any? = try {
        val rb = requestBodyClass ?: return null
        val nb = request.javaClass.getMethod("newBuilder").invoke(request) ?: return null
        val method = requestMethod(request) ?: return null
        val m = nb.javaClass.getMethod("method", String::class.java, rb)
        m.invoke(nb, method, newBody)
        nb.javaClass.getMethod("build").invoke(nb)
    } catch (t: Throwable) {
        null
    }

    // ------------------------------------------------------------------ Body IO

    fun bodyContentType(body: Any): Any? = try {
        body.javaClass.getMethod("contentType").invoke(body)
    } catch (t: Throwable) {
        null
    }

    fun bodyContentLength(body: Any): Long = try {
        (body.javaClass.getMethod("contentLength").invoke(body) as? Number)?.toLong() ?: -1L
    } catch (t: Throwable) {
        -1L
    }

    /** one-shot / duplex 的 body 读一次就没了，绝不能改写 */
    fun isOneShot(body: Any): Boolean = try {
        body.javaClass.getMethod("isOneShot").invoke(body) as? Boolean ?: false
    } catch (t: Throwable) {
        false
    }

    fun isDuplex(body: Any): Boolean = try {
        body.javaClass.getMethod("isDuplex").invoke(body) as? Boolean ?: false
    } catch (t: Throwable) {
        false
    }

    /** 把 RequestBody 写进 okio.Buffer 后读出原始字节 */
    fun readRequestBodyBytes(body: Any): ByteArray? = try {
        val sink = bufferedSinkClass ?: return null
        val buffer = newBuffer() ?: return null
        val m = body.javaClass.getMethod("writeTo", sink)
        m.invoke(body, buffer)
        readBuffer(buffer)
    } catch (t: Throwable) {
        null
    }

    fun newBuffer(): Any? = Reflect.newInstance(bufferClass ?: return null)

    fun readBuffer(buffer: Any): ByteArray? = try {
        buffer.javaClass.getMethod("readByteArray").invoke(buffer) as? ByteArray
    } catch (t: Throwable) {
        null
    }

    fun bufferWrite(buffer: Any, bytes: ByteArray): Boolean = try {
        buffer.javaClass.getMethod("write", ByteArray::class.java).invoke(buffer, bytes)
        true
    } catch (t: Throwable) {
        false
    }

    // ------------------------------------------------------------------ Body 构造

    fun createRequestBody(bytes: ByteArray, contentType: Any?): Any? =
        createBody(requestBodyClass, bytes, contentType)

    fun createResponseBody(bytes: ByteArray, contentType: Any?): Any? =
        createBody(responseBodyClass, bytes, contentType)

    /**
     * 兼容多种签名：
     *   OkHttp 3.x: create(MediaType, byte[])
     *   OkHttp 4.x: create(byte[], MediaType, int offset, int byteCount)
     *   OkHttp 5.x: create(byte[], MediaType, int, int)
     */
    private fun createBody(target: Class<*>?, bytes: ByteArray, contentType: Any?): Any? {
        if (target == null) return null
        return try {
            val candidates = target.methods
                .filter { Modifier.isStatic(it.modifiers) && it.name == "create" }
                .filter { m -> m.parameterTypes.any { it == ByteArray::class.java } }
                .sortedBy { it.parameterTypes.size }
            for (m in candidates) {
                val args = ArrayList<Any?>(m.parameterTypes.size)
                var intSeen = 0
                var ok = true
                for (p in m.parameterTypes) {
                    when {
                        p == ByteArray::class.java -> args.add(bytes)
                        mediaTypeClass != null && p == mediaTypeClass -> args.add(contentType)
                        p == Int::class.javaPrimitiveType -> {
                            // (offset, byteCount)：第一个 int 是 offset，第二个是长度
                            args.add(if (intSeen == 0) 0 else bytes.size)
                            intSeen++
                        }
                        else -> {
                            ok = false
                        }
                    }
                    if (!ok) break
                }
                if (!ok || args.size != m.parameterTypes.size) continue
                val r = m.invoke(null, *args.toTypedArray())
                if (r != null) return r
            }
            null
        } catch (t: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ Response 流

    /**
     * 用 peek 视图读取响应体（不消费原始流）。
     *
     * 关键点：
     *  - peek() 与原流共享同一个缓冲区，但不会把数据从原流里取走；
     *  - 用 request(n) 预读到指定字节数；
     *  - 用 snapshot() 拿到 ByteString 副本（snapshot 不会清空缓冲区）。
     */
    fun peekSnapshot(source: Any, maxBytes: Long): ByteArray? = try {
        val bs = bufferedSourceClass ?: return null
        val peek = bs.getMethod("peek").invoke(source) ?: return null
        val requested = bs.getMethod("request", java.lang.Long.TYPE).invoke(peek, maxBytes) as? Boolean ?: false
        val exhausted = bs.getMethod("exhausted").invoke(peek) as? Boolean ?: false
        if (!requested && !exhausted) return null
        val snapshot = bs.getMethod("snapshot").invoke(peek) ?: return null
        byteStringClass?.getMethod("toByteArray")?.invoke(snapshot) as? ByteArray
    } catch (t: Throwable) {
        null
    }

    /** 读取 RealResponseBody 内部的 source 字段（避免在 source() 钩子里递归调用） */
    fun readResponseSource(body: Any): Any? = Reflect.readField(body, "source")

    /** 读取 ResponseBody.source() 的返回值（需要在 source() 钩子之外调用） */
    fun responseSource(body: Any): Any? = try {
        body.javaClass.getMethod("source").invoke(body)
    } catch (t: Throwable) {
        null
    }

    fun responseContentLength(response: Any): Long = try {
        (response.javaClass.getMethod("contentLength").invoke(response) as? Number)?.toLong() ?: -1L
    } catch (t: Throwable) {
        -1L
    }
}

/** 标记：Request 已被本模块改写 */
object RewriteMarker
