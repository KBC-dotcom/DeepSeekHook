package com.hook.deepseek.engine.util

import android.util.Log
import com.hook.deepseek.xapi.XHookApi
import java.io.File
import java.io.FileWriter

/**
 * 统一日志出口。
 *
 * 日志默认脱敏（不记录请求/响应正文，只记长度与摘要）。
 *
 * 除了 android.util.Log 和 Xposed 日志，还会把同样的内容写到
 * 【目标 App 自己的 files 目录】里：
 *   /data/data/com.deepseek.chat/files/dsh/hook.log
 * 原因：普通 App 读不到别的应用的 logcat（Android 4.1 之后同 UID 隔离），
 * 但这个文件可以直接用 root cat 出来看，排查问题方便得多。
 */
object DshLog {

    const val TAG = "DeepSeekHook"

    /** 日志文件相对目标 App files 目录的位置 */
    const val LOG_RELATIVE_PATH = "dsh/hook.log"

    @Volatile
    var api: XHookApi? = null

    @Volatile
    var debugEnabled = false

    @Volatile
    var redact = true

    @Volatile
    private var logFile: File? = null

    private fun file(): File? {
        val cached = logFile
        if (cached != null) return cached
        return try {
            val ctx = AppContext.current() ?: return null
            val dir = File(ctx.filesDir, "dsh")
            if (!dir.exists()) dir.mkdirs()
            val f = File(dir, "hook.log")
            logFile = f
            f
        } catch (t: Throwable) {
            null
        }
    }

    private fun append(level: String, msg: String) {
        val f = file() ?: return
        try {
            // 超过 1 MB 就重新开始，避免无限增长
            if (f.exists() && f.length() > 1024L * 1024L) f.writeText("")
            FileWriter(f, true).use {
                it.write("${System.currentTimeMillis()} [$level] $msg\n")
            }
        } catch (t: Throwable) {
            // 写不进去就算了，不能影响主流程
        }
    }

    fun i(msg: String) {
        Log.i(TAG, msg)
        api?.log(msg)
        append("I", msg)
    }

    fun d(msg: String) {
        if (!debugEnabled) return
        Log.d(TAG, msg)
        api?.log(msg)
        append("D", msg)
    }

    fun e(msg: String, t: Throwable?) {
        Log.e(TAG, msg, t)
        api?.logError(msg, t ?: RuntimeException("unknown"))
        append("E", "$msg : ${t?.javaClass?.name}: ${t?.message}")
    }

    /** 脱敏：只保留长度 */
    fun redact(text: String?): String {
        if (text == null) return "null"
        return if (redact) "[len=${text.length}]" else text
    }

    /** 摘要：首尾各留一小段，便于排查又不泄露全文 */
    fun summary(text: String?, head: Int = 48): String {
        if (text == null) return "null"
        if (!redact) return text
        if (text.length <= head * 2) return "[len=${text.length}]"
        return "[len=${text.length}] " + text.substring(0, head) + " ... " + text.substring(text.length - head)
    }
}
