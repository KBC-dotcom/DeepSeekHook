package com.hook.deepseek.engine

import com.hook.deepseek.core.config.HookConfig
import com.hook.deepseek.core.prompt.ResponseRewriter
import com.hook.deepseek.core.prompt.TransformContext
import com.hook.deepseek.engine.config.ConfigClient
import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.xapi.XHookApi
import java.util.WeakHashMap

/**
 * 响应流拦截（第二层）。
 *
 * 设计文档里写的是「Hook RealResponseBody 的构造函数」，本实现按该思路落地，
 * 但做了一个关键修正：
 *
 *   Xposed 不允许替换构造器创建出来的实例（构造器的返回值就是 this），
 *   所以「拿到 source 后返回一个新的 ResponseBody」无法在构造器钩子里完成。
 *
 * 本实现的分工：
 *   - 构造器钩子：记录 contentType / contentLength / source（设计文档的“唯一稳定入口”）；
 *   - source() 钩子：真正把改写后的字节作为新的 BufferedSource 返回；
 *   - contentLength() 钩子：让长度与改写后的内容保持一致。
 *
 * 流式安全：
 *   - 用 peek() 视图读取，不消费原始流；失败时原样回退，App 仍能拿到完整原始响应；
 *   - 明确排除 text/event-stream（SSE），避免预读阻塞首块数据交付；
 *   - 在 source() 调用线程内同步完成：App 本来就要把整个 body 读完，
 *     同步读取不会改变背压语义，也避免了「后台线程读流 + 前台线程同时读」的数据竞争。
 */
object ResponseLayer {

    private class State {
        var attempted = false
        var newSource: Any? = null
        var newLength: Long? = null
    }

    private val states = WeakHashMap<Any, State>()

    private fun stateOf(instance: Any): State = synchronized(states) {
        states.getOrPut(instance) { State() }
    }

    fun install(api: XHookApi, bridge: OkHttpBridge) {
        val realBody = bridge.realResponseBodyClass ?: return

        // 构造器：抓取元信息
        api.hookAllConstructors(realBody, after = { p ->
            try {
                val inst = p.thisObject ?: return@after
                val ct = bridge.bodyContentType(inst)?.toString()
                DshLog.d("RealResponseBody constructed: ct=$ct len=${bridge.bodyContentLength(inst)}")
            } catch (t: Throwable) {
                DshLog.e("RealResponseBody ctor hook failed", t)
            }
        })

        // 真正的替换点
        api.hookAllMethods(realBody, "source", before = { p ->
            try {
                val inst = p.thisObject ?: return@before
                val rewritten = rewrite(bridge, inst) ?: return@before
                p.setResult(rewritten)
            } catch (t: Throwable) {
                DshLog.e("RealResponseBody.source hook failed", t)
            }
        })

        // 长度一致性
        api.hookAllMethods(realBody, "contentLength", after = { p ->
            try {
                val inst = p.thisObject ?: return@after
                val len = rewrittenLength(inst)
                if (len != null) p.setResult(len)
            } catch (t: Throwable) {
                DshLog.e("RealResponseBody.contentLength hook failed", t)
            }
        })
    }

    fun rewrittenLength(instance: Any): Long? {
        val st = synchronized(states) { states[instance] } ?: return null
        synchronized(st) { return st.newLength }
    }

    /**
     * 读取响应体 -> 改写 -> 返回新的 BufferedSource。
     * 任何环节失败都返回 null（保留原始响应）。
     */
    private fun rewrite(bridge: OkHttpBridge, instance: Any): Any? {
        val st = stateOf(instance)
        synchronized(st) {
            if (st.attempted) return st.newSource
            st.attempted = true

            val cfg: HookConfig = ConfigClient.current()
            if (!cfg.enabled || !cfg.rewriteResponse) return null

            val ctObj = bridge.bodyContentType(instance)
            val ct = ctObj?.toString()
            if (!cfg.matchesContentType(ct)) return null
            // SSE：流式响应不预读，避免改变背压与首块交付时机
            if (ct != null && ct.contains("event-stream", ignoreCase = true)) return null

            val len = bridge.bodyContentLength(instance)
            if (len > cfg.maxRewriteBytes) return null

            val source = bridge.readResponseSource(instance) ?: bridge.responseSource(instance) ?: return null
            val cap = if (len > 0) len else cfg.maxRewriteBytes.toLong()
            val bytes = bridge.peekSnapshot(source, cap) ?: return null
            if (bytes.isEmpty() || bytes.size > cfg.maxRewriteBytes) return null

            val chain = ChainCache.get(cfg)
            val ctx = TransformContext(
                config = cfg,
                role = "assistant",
                messageIndex = 0,
                totalMessages = 0,
                isFirstUserMessage = true,
                isLastUserMessage = true,
                direction = TransformContext.Direction.RESPONSE
            )
            val result = ResponseRewriter.rewrite(bytes, chain, ctx)
            if (!result.changed || result.bytes == null) return null

            val newSource = bridge.newBuffer() ?: return null
            if (!bridge.bufferWrite(newSource, result.bytes)) return null

            st.newSource = newSource
            st.newLength = result.bytes.size.toLong()
            DshLog.d("response body rewritten: ${bytes.size} -> ${result.bytes.size} bytes")
            return newSource
        }
    }
}
