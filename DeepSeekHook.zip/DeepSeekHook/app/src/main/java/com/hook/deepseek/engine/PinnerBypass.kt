package com.hook.deepseek.engine

import com.hook.deepseek.engine.config.ConfigClient
import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.xapi.XHookApi

/**
 * 证书固定（Certificate Pinning）绕过。
 *
 * OkHttp 的 CertificatePinner 在 TLS 握手阶段做证书链校验，
 * 直接把 check 变成空实现即可——这是最短路径。
 *
 * 兼容性：OkHttp 4.x 的公开 check 方法在字节码里叫 check(String, Function1)，
 * 旧的 @Deprecated 重载叫 -deprecated_check。两个都 hook 掉。
 *
 * 注意：这只绕过 OkHttp 层的 pinning。
 * 如果 App 自带了 TrustManager / 自定义 SSLSocketFactory，还需要另外处理，
 * 那种情况在 DeepSeek 客户端上一般不存在。
 */
object PinnerBypass {

    fun install(api: XHookApi, bridge: OkHttpBridge) {
        val pinner = bridge.certificatePinnerClass ?: return

        val n1 = api.hookAllMethods(pinner, "check", before = { p ->
            p.setResult(null)
        })
        // OkHttp 4.x 的 deprecated 重载
        val n2 = api.hookAllMethods(pinner, "-deprecated_check", before = { p ->
            p.setResult(null)
        })

        DshLog.i("CertificatePinner disabled (check=$n1, deprecated=$n2)")

        // 可选：放宽 hostname 校验（默认关闭，影响面更大）
        if (ConfigClient.current().bypassHostnameVerifier) {
            val verifier = bridge.okHostnameVerifierClass
            if (verifier != null) {
                api.hookAllMethods(verifier, "verify", before = { p ->
                    p.setResult(p.arg(0))
                })
                DshLog.i("OkHostnameVerifier.verify relaxed")
            }
        }
    }
}
