package com.hook.deepseek.core.json

/**
 * 轻量 JSON 解析器：只解析、不重建。
 *
 * 设计要点（对应设计文档「保持字段顺序和嵌套结构与原始一致」）：
 *  1. 解析结果保留每个值在原文中的字节区间 [start, end)；
 *  2. 改写时只把目标字符串字面量替换掉，其余原文按原样保留；
 *  3. 因此字段顺序、空白、缩进、\uXXXX 转义风格都不会被重排。
 *
 * 不依赖任何第三方库（org.json 会丢顺序，gson/retrofit 体积大且会带进依赖树）。
 */
sealed class JsonNode {
    abstract val start: Int
    abstract val end: Int

    data class Obj(
        override val start: Int,
        override val end: Int,
        val members: List<Member>
    ) : JsonNode() {
        data class Member(
            val name: String,
            val nameStart: Int,
            val nameEnd: Int,
            val value: JsonNode
        )

        fun find(name: String): JsonNode? = members.firstOrNull { it.name == name }?.value
    }

    data class Arr(
        override val start: Int,
        override val end: Int,
        val items: List<JsonNode>
    ) : JsonNode()

    /** start/end 覆盖整个字符串字面量（含首尾引号） */
    data class Str(
        override val start: Int,
        override val end: Int,
        val value: String
    ) : JsonNode()

    data class Num(
        override val start: Int,
        override val end: Int,
        val text: String
    ) : JsonNode()

    data class Bool(
        override val start: Int,
        override val end: Int,
        val value: Boolean
    ) : JsonNode()

    data class Null(
        override val start: Int,
        override val end: Int
    ) : JsonNode()
}

class JsonParseException(message: String) : Exception(message)

object JsonScanner {

    /** 解析失败一律返回 null，调用方据此回退到原始字节 */
    fun parse(text: String): JsonNode? = try {
        val parser = Parser(text)
        parser.skipWhitespace()
        val node = parser.parseValue()
        parser.skipWhitespace()
        if (parser.atEnd()) node else null
    } catch (t: Throwable) {
        null
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun atEnd(): Boolean = i >= s.length

        fun skipWhitespace() {
            while (i < s.length) {
                val c = s[i]
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++ else break
            }
        }

        fun parseValue(): JsonNode {
            skipWhitespace()
            if (atEnd()) throw JsonParseException("unexpected end of input")
            return when (val c = s[i]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseStringNode()
                't' -> { expect("true"); JsonNode.Bool(i - 4, i, true) }
                'f' -> { expect("false"); JsonNode.Bool(i - 5, i, false) }
                'n' -> { expect("null"); JsonNode.Null(i - 4, i) }
                else -> if (c == '-' || c in '0'..'9') parseNumber() else throw JsonParseException("unexpected char '$c' at $i")
            }
        }

        private fun expect(literal: String) {
            if (!s.startsWith(literal, i)) throw JsonParseException("expected '$literal' at $i")
            i += literal.length
        }

        private fun parseObject(): JsonNode.Obj {
            val start = i
            i++ // {
            val members = ArrayList<JsonNode.Obj.Member>()
            skipWhitespace()
            if (!atEnd() && s[i] == '}') {
                i++
                return JsonNode.Obj(start, i, members)
            }
            while (true) {
                skipWhitespace()
                if (atEnd() || s[i] != '"') throw JsonParseException("expected object key at $i")
                val nameStart = i
                val name = parseStringValue()
                val nameEnd = i
                skipWhitespace()
                if (atEnd() || s[i] != ':') throw JsonParseException("expected ':' at $i")
                i++
                val value = parseValue()
                members.add(JsonNode.Obj.Member(name, nameStart, nameEnd, value))
                skipWhitespace()
                if (atEnd()) throw JsonParseException("unexpected end in object")
                when (s[i]) {
                    ',' -> i++
                    '}' -> { i++; return JsonNode.Obj(start, i, members) }
                    else -> throw JsonParseException("expected ',' or '}' at $i")
                }
            }
        }

        private fun parseArray(): JsonNode.Arr {
            val start = i
            i++ // [
            val items = ArrayList<JsonNode>()
            skipWhitespace()
            if (!atEnd() && s[i] == ']') {
                i++
                return JsonNode.Arr(start, i, items)
            }
            while (true) {
                items.add(parseValue())
                skipWhitespace()
                if (atEnd()) throw JsonParseException("unexpected end in array")
                when (s[i]) {
                    ',' -> i++
                    ']' -> { i++; return JsonNode.Arr(start, i, items) }
                    else -> throw JsonParseException("expected ',' or ']' at $i")
                }
            }
        }

        private fun parseStringNode(): JsonNode.Str {
            val start = i
            val v = parseStringValue()
            return JsonNode.Str(start, i, v)
        }

        private fun parseStringValue(): String {
            if (atEnd() || s[i] != '"') throw JsonParseException("expected string at $i")
            i++
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonParseException("unexpected end in string")
                val c = s[i]
                if (c == '"') {
                    i++
                    return sb.toString()
                }
                if (c == '\\') {
                    i++
                    if (atEnd()) throw JsonParseException("unexpected end in escape")
                    when (val e = s[i]) {
                        '"' -> { sb.append('"'); i++ }
                        '\\' -> { sb.append('\\'); i++ }
                        '/' -> { sb.append('/'); i++ }
                        'b' -> { sb.append('\b'); i++ }
                        'f' -> { sb.append('\u000C'); i++ }
                        'n' -> { sb.append('\n'); i++ }
                        'r' -> { sb.append('\r'); i++ }
                        't' -> { sb.append('\t'); i++ }
                        'u' -> {
                            i++
                            if (i + 4 > s.length) throw JsonParseException("bad unicode escape at $i")
                            val hex = s.substring(i, i + 4)
                            val code = hex.toIntOrNull(16) ?: throw JsonParseException("bad unicode escape at $i")
                            sb.append(code.toChar())
                            i += 4
                        }
                        else -> throw JsonParseException("bad escape '\\$e' at $i")
                    }
                    continue
                }
                sb.append(c)
                i++
            }
        }

        private fun parseNumber(): JsonNode.Num {
            val start = i
            if (!atEnd() && s[i] == '-') i++
            while (!atEnd() && s[i] in '0'..'9') i++
            if (!atEnd() && s[i] == '.') {
                i++
                while (!atEnd() && s[i] in '0'..'9') i++
            }
            if (!atEnd() && (s[i] == 'e' || s[i] == 'E')) {
                i++
                if (!atEnd() && (s[i] == '+' || s[i] == '-')) i++
                while (!atEnd() && s[i] in '0'..'9') i++
            }
            return JsonNode.Num(start, i, s.substring(start, i))
        }
    }
}

/** 一次文本替换：把 [start, end) 换成 replacement */
data class TextEdit(val start: Int, val end: Int, val replacement: String)

object JsonText {

    /** 生成 JSON 字符串字面量（含引号） */
    fun escape(value: String): String {
        val sb = StringBuilder(value.length + 16)
        sb.append('"')
        for (c in value) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else ->
                    if (c < ' ' || c == '\\u2028' || c == '\\u2029') {
                        sb.append("\\u")
                        val hex = Integer.toHexString(c.code)
                        repeat(4 - hex.length) { sb.append('0') }
                        sb.append(hex)
                    } else {
                        sb.append(c)
                    }
            }
        }
        sb.append('"')
        return sb.toString()
    }

    /** 按偏移量做替换；重叠的编辑会被跳过（防御性，正常路径不会产生重叠） */
    fun splice(text: String, edits: List<TextEdit>): String {
        if (edits.isEmpty()) return text
        val sorted = edits.sortedBy { it.start }
        val sb = StringBuilder(text.length + 64)
        var cursor = 0
        for (e in sorted) {
            if (e.start < cursor || e.end > text.length || e.start > e.end) continue
            sb.append(text, cursor, e.start)
            sb.append(e.replacement)
            cursor = e.end
        }
        sb.append(text, cursor, text.length)
        return sb.toString()
    }
}
