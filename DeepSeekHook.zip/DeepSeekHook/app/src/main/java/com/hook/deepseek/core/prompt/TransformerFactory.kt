package com.hook.deepseek.core.prompt

import com.hook.deepseek.core.config.HookConfig
import com.hook.deepseek.core.config.TransformerSpec

/**
 * 根据配置构建变换器链。
 * 新增自定义变换器只需要在这里加一个分支 + 在 core/prompt 里实现 PromptTransformer。
 */
object TransformerFactory {

    fun build(cfg: HookConfig): TransformerChain {
        val list = ArrayList<PromptTransformer>()
        for (spec in cfg.transformers) {
            if (!spec.enabled) continue
            val t = create(spec)
            if (t != null) list.add(t)
        }
        return TransformerChain(list)
    }

    private fun create(spec: TransformerSpec): PromptTransformer? = try {
        when (spec.id) {
            "whitespace" -> WhitespaceNormalizer()
            "terminology" -> TerminologyReplacer(parsePairs(spec.params["pairs"]))
            "prefix" -> ConditionalPrefixInjector(
                template = spec.params["template"].orEmpty(),
                trigger = compileTrigger(spec.params["trigger"]),
                scope = parseScope(spec.params["scope"])
            )
            else -> null
        }
    } catch (t: Throwable) {
        null
    }

    /**
     * 术语表格式：每行一条「原文 => 译文」，以 => 或 => 前后空格分隔。
     */
    fun parsePairs(text: String?): List<Pair<String, String>> {
        if (text.isNullOrBlank()) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val idx = line.indexOf("=>")
            if (idx <= 0) continue
            val from = line.substring(0, idx).trim()
            val to = line.substring(idx + 2).trim()
            if (from.isEmpty()) continue
            out.add(from to to)
        }
        return out
    }

    private fun compileTrigger(text: String?): Regex? {
        if (text.isNullOrBlank()) return null
        return try {
            Regex(text)
        } catch (t: Throwable) {
            null
        }
    }

    private fun parseScope(text: String?): ConditionalPrefixInjector.Scope = when (text?.trim()?.lowercase()) {
        "first" -> ConditionalPrefixInjector.Scope.FIRST_USER
        "all" -> ConditionalPrefixInjector.Scope.ALL_USER
        else -> ConditionalPrefixInjector.Scope.LAST_USER
    }
}
