package com.hook.deepseek.engine.conceal

import android.content.pm.ApplicationInfo
import android.content.pm.NameNotFoundException
import android.content.pm.PackageInfo
import android.content.pm.ResolveInfo
import android.system.Os
import com.hook.deepseek.BuildConfig
import com.hook.deepseek.core.config.ConcealConfig
import com.hook.deepseek.engine.config.ConfigClient
import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.engine.util.Reflect
import com.hook.deepseek.xapi.XHookApi

/**
 * root / Xposed 环境隐藏。
 *
 * 覆盖四条通道：
 *   1. 包管理器枚举（PackageManager）—— 命中即抛 NameNotFoundException 或从列表里剔除；
 *   2. android.os.Build 静态字段 —— 覆盖成未 root 的机型；
 *   3. SystemProperties.get / native_get —— 与 Build 保持一致；
 *   4. android.system.Os.uname() —— 覆盖内核版本串。
 *
 * 另外屏蔽目标进程里对 Xposed/LSPosed 类的加载（只针对 App 自己的 ClassLoader，
 * 不会影响 LSPosed 框架自身的类加载）。
 *
 * 关于内核层面的痕迹（/proc 挂载点、magisk 挂载、uname）：
 *   那部分属于内核态，必须靠 SUSFS（内核补丁）处理，模块只能做用户态的配合，
 *   详见 README 的「SUSFS 配合」一节。
 */
object Conceal {

    /** 常见的 root / 框架管理器包名 */
    private val BASE_BLOCKED_PACKAGES = setOf(
        "org.lsposed.manager",
        "org.lsposed.daemon",
        "com.topjohnwu.magisk",
        "com.topjohnwu.magisk.alpha",
        "com.topjohnwu.magisk.delta",
        "com.dergoogler.magisk",
        "me.weishu.kernelsu",
        "me.weishu.kernelsu.manager",
        "com.noshufou.android.su",
        "eu.chainfire.supersu",
        "com.koushikdutta.superuser",
        "com.thirdparty.superuser",
        "com.ryosoftware.suhide",
        "com.topjohnwu.magisk.hide"
    )

    /** 禁止在目标进程里加载的类前缀 */
    private val BLOCKED_CLASS_PREFIXES = listOf(
        "de.robv.android.xposed.",
        "org.lsposed.",
        "io.github.libxposed.",
        "com.topjohnwu.magisk.",
        "me.weishu.kernelsu.",
        "com.noshufou.android.su.",
        "eu.chainfire.supersu."
    )

    private fun liveConcealConfig(): ConcealConfig = ConfigClient.current().conceal

    private fun blockedPackages(): Set<String> {
        val cfg = liveConcealConfig()
        val set = LinkedHashSet(BASE_BLOCKED_PACKAGES)
        // 模块自身包名也要藏起来
        set.add(BuildConfig.APPLICATION_ID)
        cfg.extraBlockedPackages.split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { set.add(it) }
        return set
    }

    private fun isBlockedPackage(name: String?): Boolean {
        if (name.isNullOrEmpty()) return false
        return blockedPackages().contains(name)
    }

    private fun loadBootClass(name: String): Class<*>? = try {
        Class.forName(name, false, null)
    } catch (t: Throwable) {
        null
    }

    // ------------------------------------------------------------------ 安装入口

    fun install(api: XHookApi, appClassLoader: ClassLoader) {
        val cfg = liveConcealConfig()
        if (cfg.hideRootPackages) installPackageFilter(api)
        if (cfg.hideXposedClasses) installClassFilter(api, appClassLoader)
        if (cfg.spoofBuild) installBuildSpoof(api)
        if (cfg.spoofSystemProperties) installSystemProperties(api)
        if (cfg.spoofUname) installUname(api)
    }

    // ------------------------------------------------------------------ 1. 包管理器过滤

    private fun installPackageFilter(api: XHookApi) {
        val pm = loadBootClass("android.app.ApplicationPackageManager") ?: run {
            DshLog.d("ApplicationPackageManager not found")
            return
        }

        api.hookAllMethods(pm, "getPackageInfo", before = { p ->
            val name = p.arg(0) as? String ?: return@before
            if (isBlockedPackage(name)) throw NameNotFoundException(name)
        })
        api.hookAllMethods(pm, "getApplicationInfo", before = { p ->
            val name = p.arg(0) as? String ?: return@before
            if (isBlockedPackage(name)) throw NameNotFoundException(name)
        })
        api.hookAllMethods(pm, "getLaunchIntentForPackage", after = { p ->
            val name = p.arg(0) as? String ?: return@after
            if (isBlockedPackage(name)) p.setResult(null)
        })

        api.hookAllMethods(pm, "getInstalledPackages", after = { p ->
            val list = p.result as? List<*> ?: return@after
            val filtered = list.filter { item ->
                val pi = item as? PackageInfo ?: return@filter true
                !isBlockedPackage(pi.packageName)
            }
            if (filtered.size != list.size) p.setResult(filtered)
        })
        api.hookAllMethods(pm, "getInstalledApplications", after = { p ->
            val list = p.result as? List<*> ?: return@after
            val filtered = list.filter { item ->
                val ai = item as? ApplicationInfo ?: return@filter true
                !isBlockedPackage(ai.packageName)
            }
            if (filtered.size != list.size) p.setResult(filtered)
        })
        api.hookAllMethods(pm, "queryIntentActivities", after = { p ->
            val list = p.result as? List<*> ?: return@after
            val filtered = list.filter { item ->
                val ri = item as? ResolveInfo ?: return@filter true
                !isBlockedPackage(ri.activityInfo?.packageName)
            }
            if (filtered.size != list.size) p.setResult(filtered)
        })
        api.hookAllMethods(pm, "queryIntentServices", after = { p ->
            val list = p.result as? List<*> ?: return@after
            val filtered = list.filter { item ->
                val ri = item as? ResolveInfo ?: return@filter true
                !isBlockedPackage(ri.serviceInfo?.packageName)
            }
            if (filtered.size != list.size) p.setResult(filtered)
        })
        api.hookAllMethods(pm, "resolveActivity", after = { p ->
            val ri = p.result as? ResolveInfo ?: return@after
            if (isBlockedPackage(ri.activityInfo?.packageName)) p.setResult(null)
        })
        api.hookAllMethods(pm, "resolveService", after = { p ->
            val ri = p.result as? ResolveInfo ?: return@after
            if (isBlockedPackage(ri.serviceInfo?.packageName)) p.setResult(null)
        })
        api.hookAllMethods(pm, "getPackagesForUid", after = { p ->
            val arr = p.result as? Array<*> ?: return@after
            val filtered = arr.map { it as? String }.filterNotNull().filter { !isBlockedPackage(it) }
            if (filtered.size != arr.size) p.setResult(filtered.toTypedArray())
        })

        DshLog.i("PackageManager filter installed")
    }

    // ------------------------------------------------------------------ 2. 类加载过滤

    private fun installClassFilter(api: XHookApi, appClassLoader: ClassLoader) {
        val loaderClass = loadBootClass("java.lang.ClassLoader") ?: return
        api.hookAllMethods(loaderClass, "loadClass", before = { p ->
            try {
                // 只针对 App 自己的 ClassLoader 生效，
                // 否则会误伤 LSPosed 框架自身的类加载
                if (p.thisObject !== appClassLoader) return@before
                val name = p.arg(0) as? String ?: return@before
                if (name == BuildConfig.APPLICATION_ID) return@before
                for (prefix in BLOCKED_CLASS_PREFIXES) {
                    if (name.startsWith(prefix)) {
                        throw ClassNotFoundException(name)
                    }
                }
            } catch (e: ClassNotFoundException) {
                throw e
            } catch (t: Throwable) {
                DshLog.e("class filter failed", t)
            }
        })
        DshLog.i("ClassLoader filter installed")
    }

    // ------------------------------------------------------------------ 3. Build 伪装

    private fun installBuildSpoof(api: XHookApi) {
        val build = loadBootClass("android.os.Build") ?: return
        val values = mapOf(
            "TAGS" to "release-keys",
            "TYPE" to "user",
            "FINGERPRINT" to "Redmi/K24090MR1C/14:UP1A.231005.007/11000000:user/release-keys",
            "MODEL" to "24031PN0DC",
            "BRAND" to "Xiaomi",
            "DEVICE" to "houji",
            "PRODUCT" to "houji",
            "MANUFACTURER" to "Xiaomi",
            "HARDWARE" to "qcom",
            "BOARD" to "houji",
            "DISPLAY" to "TKQ1.221114.001",
            "ID" to "TKQ1.221114.001",
            "HOST" to "k8s",
            "SERIAL" to "0000000000000000",
            "BOOTLOADER" to "unknown"
        )
        var ok = 0
        var failed = 0
        for ((k, v) in values) {
            if (api.setStaticObjectField(build, k, v)) ok++ else failed++
        }
        DshLog.i("Build spoof: $ok written, $failed failed (Android 12+ 可能拒绝写入 boot image 里的 final 静态字段)")
    }

    // ------------------------------------------------------------------ 4. SystemProperties 伪装

    private fun installSystemProperties(api: XHookApi) {
        val sp = loadBootClass("android.os.SystemProperties") ?: run {
            DshLog.d("SystemProperties not found")
            return
        }
        val stringValues = mapOf(
            "ro.build.tags" to "release-keys",
            "ro.build.type" to "user",
            "ro.build.fingerprint" to "Redmi/K24090MR1C/14:UP1A.231005.007/11000000:user/release-keys",
            "ro.product.model" to "24031PN0DC",
            "ro.product.brand" to "Xiaomi",
            "ro.product.device" to "houji",
            "ro.product.name" to "houji",
            "ro.product.manufacturer" to "Xiaomi",
            "ro.build.description" to "user/release-keys",
            "ro.build.version.incremental" to "11000000",
            "ro.boot.verifiedbootstate" to "green",
            "ro.boot.vbmeta.device_state" to "locked"
        )
        val intValues = mapOf(
            "ro.debuggable" to 0,
            "ro.secure" to 1,
            "ro.boot.flash.locked" to 1
        )
        val boolValues = mapOf(
            "ro.debuggable" to false,
            "ro.secure" to true
        )

        api.hookAllMethods(sp, "get", after = { p ->
            val key = p.arg(0) as? String ?: return@after
            val v = stringValues[key] ?: return@after
            p.setResult(v)
        })
        api.hookAllMethods(sp, "native_get", after = { p ->
            val key = p.arg(0) as? String ?: return@after
            val v = stringValues[key] ?: return@after
            p.setResult(v)
        })
        api.hookAllMethods(sp, "getInt", after = { p ->
            val key = p.arg(0) as? String ?: return@after
            val v = intValues[key] ?: return@after
            p.setResult(v)
        })
        api.hookAllMethods(sp, "getLong", after = { p ->
            val key = p.arg(0) as? String ?: return@after
            val v = intValues[key] ?: return@after
            p.setResult(v.toLong())
        })
        api.hookAllMethods(sp, "getBoolean", after = { p ->
            val key = p.arg(0) as? String ?: return@after
            val v = boolValues[key] ?: return@after
            p.setResult(v)
        })
        DshLog.i("SystemProperties spoof installed")
    }

    // ------------------------------------------------------------------ 5. uname 伪装

    private fun installUname(api: XHookApi) {
        api.hookAllMethods(Os::class.java, "uname", after = { p ->
            try {
                val u = p.result as? Os.Uname ?: return@after
                Reflect.writeField(u, "sysname", "Linux")
                Reflect.writeField(u, "nodename", "localhost")
                Reflect.writeField(u, "release", "5.15.78-android13-2-00021-g1a2b3c4d5e-ab11223344")
                Reflect.writeField(u, "version", "#1 SMP PREEMPT Tue Jan 1 00:00:00 UTC 2024")
                Reflect.writeField(u, "machine", "aarch64")
            } catch (t: Throwable) {
                DshLog.e("uname spoof failed", t)
            }
        })
        DshLog.i("Os.uname spoof installed")
    }
}
