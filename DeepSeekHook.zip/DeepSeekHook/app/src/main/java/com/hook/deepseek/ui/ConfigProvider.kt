package com.hook.deepseek.ui

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import com.hook.deepseek.core.config.ConfigJson

/**
 * 跨进程配置通道。
 *
 * 目标进程（DeepSeek）与模块 App 不同 UID，读不到模块 App 的 SharedPreferences，
 * 所以由这个 exported Provider 把配置 JSON 暴露给目标进程查询。
 * 返回内容只有配置项，不含任何敏感信息。
 */
class ConfigProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val ctx = context ?: return null
        val cfg = ConfigStore.load(ctx)
        val cursor = MatrixCursor(arrayOf("config"))
        cursor.addRow(arrayOf<Any?>(ConfigJson.toJson(cfg)))
        return cursor
    }

    override fun getType(uri: Uri): String = "vnd.android.cursor.item/vnd.hook.deepseek.config"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0
}
