package com.hook.deepseek.core.prompt

import com.hook.deepseek.core.config.HookConfig

/**
 * 单次变换的上下文。
 */
data class TransformContext(
    val config: HookConfig,
    val role: String,
    val messageIndex: Int,
    val totalMessages: Int,
    val isFirstUserMessage: Boolean,
    val isLastUserMessage: Boolean,
    val direction: Direction
) {
    enum class Direction { REQUEST, RESPONSE }
}

/**
 * 可插拔的提示词变换器。
 *
 * 约定（对应设计文档「每个 Transformer 只做确定性、可逆或语义保持的变换」）：
 *  - 必须是纯函数：同样输入永远得到同样输出；
 *  - 返回 null 表示本次不做任何改动；
 *  - 抛出异常视为整条链失败，上层会回退到原始字节。
 */
interface PromptTransformer {
    val id: String
    fun transform(input: String, ctx: TransformContext): String?
}

/**
 * 空白规范化：压缩多余空行、去掉行尾空白、把不换行空格折成普通空格。
 * 不触碰任何实义字符，token 边界基本保持。
 */
class WhitespaceNormalizer : PromptTransformer {
    override val id: String = "whitespace"

    override fun transform(input: String, ctx: TransformContext): String? {
        if (input.isEmpty()) return null
        var s = input.replace('\\u00A0', ' ')
        s = TRAILING_WS.replace(s, "\n")
        s = MULTI_NEWLINE.replace(s, "\n\n")
        s = MULTI_SPACE.replace(s, "  ")
        return if (s == input) null else s
    }

    companion object {
        private val TRAILING_WS = Regex("[ \t]+\n")
        private val MULTI_NEWLINE = Regex("\n{3,}")
        private val MULTI_SPACE = Regex("[ \t]{3,}")
    }
}

/**
 * 术语替换：按用户词典做确定性替换。
 * ASCII 词条要求词边界（避免改到更大的单词里），CJK 词条直接替换。
 * 长词优先，避免短词先命中造成语义偏差。
 */
class TerminologyReplacer(pairs: List<Pair<String, String>>) : PromptTransformer {
    override val id: String = "terminology"

    private val pairs: List<Pair<String, String>> =
        pairs.filter { it.first.isNotEmpty() && it.first != it.second }
            .sortedByDescending { it.first.length }

    override fun transform(input: String, ctx: TransformContext): String? {
        if (pairs.isEmpty()) return null
        var s = input
        var changed = false
        for ((from, to) in pairs) {
            val r = if (isAscii(from)) replaceWord(s, from, to) else s.replace(from, to)
            if (r != s) {
                s = r
                changed = true
            }
        }
        return if (changed) s else null
    }

    private fun isAscii(t: String): Boolean = t.all { it.code < 128 }

    private fun replaceWord(src: String, from: String, to: String): String {
        if (from.isEmpty()) return src
        val sb = StringBuilder(src.length)
        var i = 0
        while (i < src.length) {
            val idx = src.indexOf(from, i)
            if (idx < 0) {
                sb.append(src, i, src.length)
                break
            }
            val end = idx + from.length
            val leftOk = idx == 0 || !isWordChar(src[idx - 1])
            val rightOk = end >= src.length || !isWordChar(src[end])
            sb.append(src, i, idx)
            sb.append(if (leftOk && rightOk) to else from)
            i = end
        }
        return sb.toString()
    }

    private fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || c == '_'
}

/**
 * 条件性前缀注入：只有命中触发条件时才注入前缀。
 * 模板中可写 {content} 占位符；不写则前缀独占一行追加在正文之前。
 * 注入是幂等的：正文已经以该前缀开头时不再重复注入。
 */
class ConditionalPrefixInjector(
    private val template: String,
    private val trigger: Regex?,
    private val scope: Scope
) : PromptTransformer {
    override val id: String = "prefix"

    enum class Scope { LAST_USER, FIRST_USER, ALL_USER }

    override fun transform(input: String, ctx: TransformContext): String? {
        if (template.isBlank()) return null
        if (!scope.applies(ctx)) return null
        if (trigger != null && !trigger.containsMatchIn(input)) return null

        val hasSlot = template.contains("{content}")
        val head = if (hasSlot) template else template.trimEnd() + "\n"
        if (!hasSlot && input.startsWith(head)) return null
        val out = if (hasSlot) template.replace("{content}", input) else head + input
        return if (out == input) null else out
    }

    private fun Scope.applies(ctx: TransformContext): Boolean = when (this) {
        Scope.LAST_USER -> ctx.isLastUserMessage
        Scope.FIRST_USER -> ctx.isFirstUserMessage
        Scope.ALL_USER -> true
    }
}

/**
 * 变换器链：按顺序串联。
 * 任一环节抛异常 -> 返回 null -> 上层整体回退到原始字节（绝不输出半改写状态）。
 */
class TransformerChain(val transformers: List<PromptTransformer>) {

    fun transform(input: String, ctx: TransformContext): String? {
        if (transformers.isEmpty()) return null
        var s = input
        for (t in transformers) {
            val r = try {
                t.transform(s, ctx)
            } catch (e: Throwable) {
                return null
            }
            if (r != null) s = r
        }
        return if (s == input) null else s
    }
}
