package com.hook.deepseek.engine

import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.xapi.XHookApi
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 两个 flavor（legacy / modern）共用的启动逻辑。
 */
object ModuleCore {

    /** 目标包名 */
    const val TARGET_PACKAGE = "com.deepseek.chat"

    private val installed = AtomicBoolean(false)

    fun start(api: XHookApi, classLoader: ClassLoader, packageName: String, processName: String?) {
        if (packageName != TARGET_PACKAGE) return
        // 只处理主进程：子进程（:push, :tools 等）里改写请求没有意义，还可能引入不必要的风险
        if (processName != null && processName != TARGET_PACKAGE) return
        if (!installed.compareAndSet(false, true)) return

        try {
            DshLog.i("bootstrapping in $packageName (pid process=$processName)")
            EngineInstaller.install(api, classLoader)
        } catch (t: Throwable) {
            api.logError("module bootstrap failed", t)
        }
    }
}
