package com.hook.deepseek.engine

import com.hook.deepseek.engine.conceal.Conceal
import com.hook.deepseek.engine.config.ConfigClient
import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.xapi.XHookApi

/**
 * 一次性把所有钩子装上。
 *
 * 关键设计：无论配置里开关怎么配，钩子都先装上，
 * 真正的行为判断放到每次调用时读实时配置（ConfigClient.current()）。
 * 这样用户在模块 App 里改配置后不需要重启目标 App 就能生效
 * （只有 Build 静态字段伪装需要重启，因为那是写字段而不是拦调用）。
 */
object EngineInstaller {

    fun install(api: XHookApi, classLoader: ClassLoader) {
        DshLog.api = api
        val cfg = ConfigClient.current()
        DshLog.debugEnabled = cfg.debugLog
        DshLog.redact = cfg.redactLog

        val bridge = OkHttpBridge(classLoader)
        if (!bridge.ok) {
            DshLog.e("target process has no okhttp classes, abort", null)
            return
        }

        try {
            PinnerBypass.install(api, bridge)
        } catch (t: Throwable) {
            DshLog.e("pinning bypass failed", t)
        }
        try {
            RequestLayer.install(api, bridge)
        } catch (t: Throwable) {
            DshLog.e("request layer failed", t)
        }
        try {
            ResponseLayer.install(api, bridge)
        } catch (t: Throwable) {
            DshLog.e("response layer failed", t)
        }
        try {
            ChainGuardLayer.install(api, bridge)
        } catch (t: Throwable) {
            DshLog.e("chain guard failed", t)
        }
        try {
            Conceal.install(api, classLoader)
        } catch (t: Throwable) {
            DshLog.e("conceal failed", t)
        }

        // App 起来后让配置缓存失效，保证首轮请求就用上最新配置
        try {
            val appClass = Class.forName("android.app.Application", false, null)
            api.hookAllMethods(appClass, "onCreate", after = {
                ConfigClient.invalidate()
            })
        } catch (t: Throwable) {
            DshLog.e("hook Application.onCreate failed", t)
        }

        DshLog.i(
            "hooks installed: okhttp=${bridge.ok} pinning=${cfg.bypassPinning} " +
                "request=${cfg.rewriteRequest} response=${cfg.rewriteResponse} conceal=${cfg.conceal.enabled}"
        )
    }
}
