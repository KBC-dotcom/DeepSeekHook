package com.hook.deepseek.ui

import android.content.Context
import com.hook.deepseek.core.config.ConfigJson
import com.hook.deepseek.core.config.HookConfig

/** 模块 App 侧的本地配置存储（SharedPreferences）。 */
object ConfigStore {

    private const val PREFS = "dsh_config"
    private const val KEY = "config_json"

    fun load(ctx: Context): HookConfig {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return ConfigJson.fromJson(prefs.getString(KEY, null))
    }

    fun save(ctx: Context, cfg: HookConfig) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY, ConfigJson.toJson(cfg)).apply()
    }
}
