package com.hook.deepseek.core.prompt

import com.hook.deepseek.core.json.JsonNode
import com.hook.deepseek.core.json.JsonScanner
import com.hook.deepseek.core.json.JsonText
import com.hook.deepseek.core.json.TextEdit

/**
 * 改写结果。
 * bytes == null 表示「不产出改写内容」，调用方必须保留原始字节。
 */
data class RewriteResult(
    val bytes: ByteArray?,
    val changed: Boolean,
    val reason: String
) {
    companion object {
        fun unchanged(reason: String): RewriteResult = RewriteResult(null, false, reason)
    }
}

/**
 * 请求侧改写：只处理 messages[] 里 role == "user" 的 content。
 *
 * content 既可能是纯字符串，也可能是多模态数组（[{type:"text",text:"..."}]），两种都支持。
 * 解析失败 / 结构不匹配 -> 整条链回退到原始字节。
 */
object MessageRewriter {

    fun rewrite(body: ByteArray, chain: TransformerChain, base: TransformContext): RewriteResult {
        val text = String(body, Charsets.UTF_8)
        val root = JsonScanner.parse(text) as? JsonNode.Obj
            ?: return RewriteResult.unchanged("json-parse-failed")
        val messages = root.find("messages") as? JsonNode.Arr
            ?: return RewriteResult.unchanged("no-messages-array")

        val userIndexes = messages.items.indices.filter { idx ->
            val m = messages.items[idx] as? JsonNode.Obj ?: return@filter false
            (m.find("role") as? JsonNode.Str)?.value == "user"
        }
        if (userIndexes.isEmpty()) return RewriteResult.unchanged("no-user-message")

        val edits = ArrayList<TextEdit>()
        userIndexes.forEachIndexed { order, idx ->
            val msg = messages.items[idx] as JsonNode.Obj
            val ctx = base.copy(
                role = "user",
                messageIndex = idx,
                totalMessages = messages.items.size,
                isFirstUserMessage = order == 0,
                isLastUserMessage = order == userIndexes.size - 1
            )
            val content = msg.find("content") ?: return@forEachIndexed
            when (content) {
                is JsonNode.Str -> {
                    val out = chain.transform(content.value, ctx) ?: return@forEachIndexed
                    edits.add(TextEdit(content.start, content.end, JsonText.escape(out)))
                }
                is JsonNode.Arr -> {
                    content.items.forEach { part ->
                        val po = part as? JsonNode.Obj ?: return@forEach
                        val type = (po.find("type") as? JsonNode.Str)?.value
                        if (type != null && type != "text") return@forEach
                        val textNode = po.find("text") as? JsonNode.Str ?: return@forEach
                        val out = chain.transform(textNode.value, ctx) ?: return@forEach
                        edits.add(TextEdit(textNode.start, textNode.end, JsonText.escape(out)))
                    }
                }
                else -> Unit
            }
        }

        if (edits.isEmpty()) return RewriteResult.unchanged("no-user-text")
        val newText = JsonText.splice(text, edits)
        if (!StructureCheck.verify(root, text, newText)) {
            return RewriteResult.unchanged("structure-mismatch")
        }
        return RewriteResult(newText.toByteArray(Charsets.UTF_8), true, "ok")
    }
}

/**
 * 响应侧改写：处理 choices[].message.content / choices[].delta.content / choices[].text。
 */
object ResponseRewriter {

    fun rewrite(body: ByteArray, chain: TransformerChain, base: TransformContext): RewriteResult {
        val text = String(body, Charsets.UTF_8)
        val root = JsonScanner.parse(text) as? JsonNode.Obj
            ?: return RewriteResult.unchanged("json-parse-failed")
        val choices = root.find("choices") as? JsonNode.Arr
            ?: return RewriteResult.unchanged("no-choices-array")

        val edits = ArrayList<TextEdit>()
        choices.items.forEachIndexed { idx, choice ->
            val co = choice as? JsonNode.Obj ?: return@forEachIndexed
            val ctx = base.copy(
                role = "assistant",
                messageIndex = idx,
                totalMessages = choices.items.size,
                isFirstUserMessage = idx == 0,
                isLastUserMessage = idx == choices.items.size - 1
            )

            val message = co.find("message") as? JsonNode.Obj
            collect(message?.find("content") as? JsonNode.Str, ctx, chain, edits)
            collect(message?.find("reasoning_content") as? JsonNode.Str, ctx, chain, edits)

            val delta = co.find("delta") as? JsonNode.Obj
            collect(delta?.find("content") as? JsonNode.Str, ctx, chain, edits)

            collect(co.find("text") as? JsonNode.Str, ctx, chain, edits)
        }

        if (edits.isEmpty()) return RewriteResult.unchanged("no-assistant-text")
        val newText = JsonText.splice(text, edits)
        if (!StructureCheck.verify(root, text, newText)) {
            return RewriteResult.unchanged("structure-mismatch")
        }
        return RewriteResult(newText.toByteArray(Charsets.UTF_8), true, "ok")
    }

    private fun collect(
        node: JsonNode.Str?,
        ctx: TransformContext,
        chain: TransformerChain,
        edits: MutableList<TextEdit>
    ) {
        if (node == null) return
        val out = chain.transform(node.value, ctx) ?: return
        edits.add(TextEdit(node.start, node.end, JsonText.escape(out)))
    }
}

/**
 * 结构校验：确认改写没有破坏报文的形状。
 *
 * 规则：
 *  - 顶层成员数量、名称、顺序必须完全一致；
 *  - 未被改写的字段，其原始文本必须逐字节相同；
 *  - 被改写的字段（content/text/...）只校验「形状」：类型一致、数组长度一致、
 *    非文本成员逐字节相同。
 * 任何一条不满足 -> 整条链回退到原始字节。
 */
object StructureCheck {

    /** 顶层允许内部结构变化的成员 */
    private val SOFT_TOP = setOf("messages", "choices", "output")

    /** 允许内容变化的成员名 */
    private val SOFT_MEMBERS = setOf("content", "text", "reasoning_content", "message", "delta")

    fun verify(original: JsonNode.Obj, originalText: String, newText: String): Boolean {
        val newRoot = JsonScanner.parse(newText) as? JsonNode.Obj ?: return false
        if (original.members.size != newRoot.members.size) return false
        for (i in original.members.indices) {
            val a = original.members[i]
            val b = newRoot.members[i]
            if (a.name != b.name) return false
            if (a.name in SOFT_TOP) {
                if (!shapeOk(a.value, b.value, originalText, newText)) return false
            } else {
                if (slice(originalText, a.value) != slice(newText, b.value)) return false
            }
        }
        return true
    }

    private fun shapeOk(o: JsonNode, n: JsonNode, oText: String, nText: String): Boolean = when {
        o is JsonNode.Str && n is JsonNode.Str -> true
        o is JsonNode.Arr && n is JsonNode.Arr ->
            o.items.size == n.items.size &&
                o.items.indices.all { shapeOk(o.items[it], n.items[it], oText, nText) }
        o is JsonNode.Obj && n is JsonNode.Obj ->
            o.members.size == n.members.size &&
                o.members.indices.all { i ->
                    val om = o.members[i]
                    val nm = n.members[i]
                    if (om.name != nm.name) {
                        false
                    } else if (om.name in SOFT_MEMBERS) {
                        shapeOk(om.value, nm.value, oText, nText)
                    } else {
                        slice(oText, om.value) == slice(nText, nm.value)
                    }
                }
        else -> o::class == n::class
    }

    private fun slice(text: String, node: JsonNode): String = text.substring(node.start, node.end)
}
