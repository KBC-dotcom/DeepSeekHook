package com.hook.deepseek.engine

import com.hook.deepseek.engine.util.DshLog
import com.hook.deepseek.xapi.XHookApi

/**
 * 兜底层（第三层）：RealInterceptorChain.proceed。
 *
 * proceed 是所有请求的必经之路，无论业务层怎么封装 OkHttpClient、
 * 是否绕过 Request.Builder 的常规路径，最终都会在这里汇合。
 *
 * 本层不作为主要改写点，而是：
 *   - 一致性校验：检查 Request 是否已经过第一层处理，未处理则就地改写；
 *   - 漏网请求的兜底。
 */
object ChainGuardLayer {

    fun install(api: XHookApi, bridge: OkHttpBridge) {
        val chainClass = bridge.realInterceptorChainClass ?: return
        val n = api.hookAllMethods(chainClass, "proceed",
            before = { p ->
                try {
                    if (RebuildGuard.inRebuild.get()) return@before
                    val request = p.arg(0) ?: return@before
                    if (bridge.isMarked(request)) return@before
                    val body = bridge.requestBody(request) ?: return@before
                    val newBody = RequestBodyRewriter.rewrite(bridge, body) ?: return@before

                    RebuildGuard.inRebuild.set(true)
                    val rebuilt = bridge.rebuildRequest(request, newBody)
                    val marked = rebuilt?.let { bridge.markRequest(it) }
                    RebuildGuard.inRebuild.remove()
                    if (marked == null) return@before
                    p.setArg(0, marked)
                    DshLog.d("chain guard rewrote an unmarked request")
                } catch (t: Throwable) {
                    RebuildGuard.inRebuild.remove()
                    DshLog.e("chain guard failed", t)
                }
            },
            after = { p ->
                try {
                    val response = p.result ?: return@after
                    val len = bridge.responseContentLength(response)
                    if (len < 0) DshLog.d("response has unknown content length")
                } catch (t: Throwable) {
                    DshLog.e("chain guard response check failed", t)
                }
            })
        DshLog.d("RealInterceptorChain.proceed hooked: $n")
    }
}
