package com.hook.deepseek.engine

import android.content.Context
import android.net.Uri
import com.hook.deepseek.BuildConfig
import com.hook.deepseek.core.config.ConfigJson
import com.hook.deepseek.core.config.HookConfig
import com.hook.deepseek.engine.util.AppContext
import com.hook.deepseek.engine.util.DshLog

/**
 * 配置读取通道。
 *
 * 目标进程（DeepSeek）与模块 App 不同 UID，共享私有的 SharedPreferences 读不到，
 * 因此模块 App 用一个 exported ContentProvider 暴露配置 JSON，
 * 目标进程通过 ContentResolver 查询。
 */
object ConfigClient {

    private const val TTL_MS = 2000L
    private const val PATH = "config"

    @Volatile
    private var cached: HookConfig? = null

    @Volatile
    private var cachedAt = 0L

    fun current(): HookConfig {
        val now = System.currentTimeMillis()
        val c = cached
        if (c != null && now - cachedAt < TTL_MS) return c
        val loaded = load()
        cached = loaded
        cachedAt = now
        return loaded
    }

    fun invalidate() {
        cachedAt = 0L
    }

    fun authority(): String = BuildConfig.APPLICATION_ID + ".provider"

    private fun load(): HookConfig {
        val ctx: Context = AppContext.current() ?: return HookConfig()
        return try {
            val uri = Uri.parse("content://" + authority() + "/" + PATH)
            ctx.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (!cursor.moveToFirst()) return HookConfig()
                val idx = cursor.getColumnIndex("config")
                if (idx < 0) HookConfig() else ConfigJson.fromJson(cursor.getString(idx))
            } ?: HookConfig()
        } catch (t: Throwable) {
            DshLog.d("config load failed: ${t.javaClass.simpleName}")
            HookConfig()
        }
    }
}
