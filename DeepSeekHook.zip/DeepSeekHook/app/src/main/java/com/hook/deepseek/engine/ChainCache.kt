package com.hook.deepseek.engine

import com.hook.deepseek.core.config.HookConfig
import com.hook.deepseek.core.config.TransformerSpec
import com.hook.deepseek.core.prompt.TransformerChain
import com.hook.deepseek.core.prompt.TransformerFactory

/** 变换器链缓存：配置没变就复用，避免重复编译正则。 */
object ChainCache {

    @Volatile
    private var chain: TransformerChain? = null

    @Volatile
    private var key: List<TransformerSpec>? = null

    fun get(cfg: HookConfig): TransformerChain {
        val k = cfg.transformers
        val c = chain
        if (c != null && key == k) return c
        val nc = TransformerFactory.build(cfg)
        chain = nc
        key = k
        return nc
    }
}

/**
 * 重建保护。
 *
 * rebuildRequest() 内部会再次调用 Request.Builder.build()，
 * 如果不加保护就会递归触发本模块自己的钩子。
 */
object RebuildGuard {
    val inRebuild = ThreadLocal.withInitial { false }
}
