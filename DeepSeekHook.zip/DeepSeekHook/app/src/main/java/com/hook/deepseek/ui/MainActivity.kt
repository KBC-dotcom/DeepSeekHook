package com.hook.deepseek.ui

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.hook.deepseek.core.config.ConfigJson
import com.hook.deepseek.core.config.HookConfig

/**
 * 配置界面。
 *
 * 刻意使用 framework 原生控件构建（不引入 androidx / material），
 * 这样模块 APK 没有任何第三方运行时依赖，体积小、加载快。
 */
class MainActivity : Activity() {

    private lateinit var cfg: HookConfig

    private lateinit var swEnabled: Switch
    private lateinit var swPinning: Switch
    private lateinit var swHostname: Switch
    private lateinit var swRequest: Switch
    private lateinit var swResponse: Switch
    private lateinit var swConceal: Switch
    private lateinit var swHidePackages: Switch
    private lateinit var swHideClasses: Switch
    private lateinit var swSpoofBuild: Switch
    private lateinit var swSpoofProps: Switch
    private lateinit var swSpoofUname: Switch
    private lateinit var swDebug: Switch

    private lateinit var etPairs: EditText
    private lateinit var etTemplate: EditText
    private lateinit var etTrigger: EditText
    private lateinit var etScope: EditText

    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = ConfigStore.load(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        root.setPadding(pad, pad, pad, pad)

        val scroll = ScrollView(this)
        scroll.addView(
            root,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(scroll)

        header(root, "总开关")
        swEnabled = switch(root, "启用模块", cfg.enabled)
        swPinning = switch(root, "绕过 OkHttp 证书固定 (CertificatePinner)", cfg.bypassPinning)
        swHostname = switch(root, "放宽 hostname 校验 (影响面更大，默认关)", cfg.bypassHostnameVerifier)
        swRequest = switch(root, "改写请求体 (Request.Builder)", cfg.rewriteRequest)
        swResponse = switch(root, "改写响应体 (ResponseBody)", cfg.rewriteResponse)

        header(root, "环境隐藏")
        swConceal = switch(root, "启用环境隐藏", cfg.conceal.enabled)
        swHidePackages = switch(root, "隐藏 root 管理器包名 (PackageManager 过滤)", cfg.conceal.hideRootPackages)
        swHideClasses = switch(root, "屏蔽 Xposed / LSPosed 类加载", cfg.conceal.hideXposedClasses)
        swSpoofBuild = switch(root, "伪装 android.os.Build 静态字段", cfg.conceal.spoofBuild)
        swSpoofProps = switch(root, "伪装 SystemProperties", cfg.conceal.spoofSystemProperties)
        swSpoofUname = switch(root, "伪装 Os.uname()", cfg.conceal.spoofUname)

        header(root, "提示词变换链")
        etPairs = edit(
            root,
            "术语表（每行一条：原文 => 译文）",
            cfg.transformers.firstOrNull { it.id == "terminology" }?.params?.get("pairs").orEmpty(),
            true
        )
        etTemplate = edit(
            root,
            "前缀模板（可写 {content} 占位符）",
            cfg.transformers.firstOrNull { it.id == "prefix" }?.params?.get("template").orEmpty(),
            true
        )
        etTrigger = edit(
            root,
            "前缀触发条件（正则，留空表示不限制）",
            cfg.transformers.firstOrNull { it.id == "prefix" }?.params?.get("trigger").orEmpty(),
            false
        )
        etScope = edit(
            root,
            "前缀作用范围（last / first / all）",
            cfg.transformers.firstOrNull { it.id == "prefix" }?.params?.get("scope").orEmpty().ifBlank { "last" },
            false
        )

        header(root, "调试")
        swDebug = switch(root, "输出调试日志", cfg.debugLog)

        val save = Button(this)
        save.text = "保存配置"
        save.setOnClickListener { save() }
        root.addView(save, lp())

        val reset = Button(this)
        reset.text = "恢复默认配置"
        reset.setOnClickListener {
            cfg = HookConfig()
            ConfigStore.save(this, cfg)
            Toast.makeText(this, "已恢复默认", Toast.LENGTH_SHORT).show()
            recreate()
        }
        root.addView(reset, lp())

        tvStatus = TextView(this)
        tvStatus.setPadding(0, pad, 0, 0)
        tvStatus.textSize = 11f
        root.addView(tvStatus, lp())

        updateStatus()
    }

    private fun save() {
        val specs = cfg.transformers.map { spec ->
            when (spec.id) {
                "terminology" -> spec.copy(
                    enabled = true,
                    params = spec.params + ("pairs" to etPairs.text.toString())
                )
                "prefix" -> spec.copy(
                    enabled = true,
                    params = spec.params + mapOf(
                        "template" to etTemplate.text.toString(),
                        "trigger" to etTrigger.text.toString(),
                        "scope" to etScope.text.toString().trim().ifBlank { "last" }
                    )
                )
                else -> spec
            }
        }

        cfg = cfg.copy(
            enabled = swEnabled.isChecked,
            bypassPinning = swPinning.isChecked,
            bypassHostnameVerifier = swHostname.isChecked,
            rewriteRequest = swRequest.isChecked,
            rewriteResponse = swResponse.isChecked,
            debugLog = swDebug.isChecked,
            conceal = cfg.conceal.copy(
                enabled = swConceal.isChecked,
                hideRootPackages = swHidePackages.isChecked,
                hideXposedClasses = swHideClasses.isChecked,
                spoofBuild = swSpoofBuild.isChecked,
                spoofSystemProperties = swSpoofProps.isChecked,
                spoofUname = swSpoofUname.isChecked
            ),
            transformers = specs
        )
        ConfigStore.save(this, cfg)
        Toast.makeText(this, "已保存（目标 App 会在 ~2s 内生效）", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        tvStatus.text = buildString {
            append("当前配置：\n")
            append(ConfigJson.toJson(cfg))
            append("\n\n作用域：com.deepseek.chat（仅主进程）\n")
            append("提示：Build 静态字段伪装在模块加载时写入，改完该项需要重启目标 App。\n")
        }
    }

    // ------------------------------------------------------------------ UI helpers

    private fun lp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun header(parent: LinearLayout, title: String) {
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 15f
        tv.setPadding(0, 24, 0, 8)
        parent.addView(tv, lp())
    }

    private fun switch(parent: LinearLayout, label: String, checked: Boolean): Switch {
        val sw = Switch(this)
        sw.text = label
        sw.isChecked = checked
        parent.addView(sw, lp())
        return sw
    }

    private fun edit(parent: LinearLayout, label: String, value: String, multiLine: Boolean): EditText {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        parent.addView(tv, lp())

        val et = EditText(this)
        et.setText(value)
        et.inputType = if (multiLine) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        if (multiLine) et.minLines = 3
        parent.addView(et, lp())
        return et
    }
}
