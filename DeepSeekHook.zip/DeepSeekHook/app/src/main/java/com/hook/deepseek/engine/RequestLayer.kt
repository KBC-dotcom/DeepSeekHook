package com.hook.deepseek.engine

import com.hook.deepseek.core.config.HookConfig
import com.hook.deepseek.core.prompt.MessageRewriter
import com.hook.deepseek.core.prompt.TransformContext
import com.hook.deepseek.engine.config.ConfigClient
import com.hook.deepseek.engine.util.DshLog

/**
 * 请求体改写（第一层）。
 *
 * 改写发生在 Request.Builder 组装阶段，早于 App 自己的签名 / 加密拦截器。
 * FormBody / MultipartBody 走同一套机制：先按字节读出原始报文，
 * 改写后再用同样的 Content-Type 构造一个新的 RequestBody。
 */
object RequestLayer {

    fun install(api: com.hook.deepseek.xapi.XHookApi, bridge: OkHttpBridge) {
        val builder = bridge.requestBuilderClass ?: return

        // 构造器：设计文档要求的第一层入口，用于捕获 Request.Builder 实例
        api.hookAllConstructors(builder, after = { p ->
            DshLog.d("Request.Builder constructed")
        })

        // method(String, RequestBody)：请求体进入 Builder 的最早期位置
        api.hookAllMethods(builder, "method", before = { p ->
            try {
                val body = p.arg(1) ?: return@before
                val newBody = RequestBodyRewriter.rewrite(bridge, body) ?: return@before
                p.setArg(1, newBody)
            } catch (t: Throwable) {
                DshLog.e("Request.Builder.method hook failed", t)
            }
        })

        // build()：常规路径之外的兜底（例如 App 自己 new Request(...) 构造）
        api.hookAllMethods(builder, "build", after = { p ->
            try {
                if (RebuildGuard.inRebuild.get()) return@after
                val request = p.result ?: return@after
                if (bridge.isMarked(request)) return@after
                val body = bridge.requestBody(request) ?: return@after
                val newBody = RequestBodyRewriter.rewrite(bridge, body) ?: return@after
                RebuildGuard.inRebuild.set(true)
                val rebuilt = bridge.rebuildRequest(request, newBody)
                val marked = rebuilt?.let { bridge.markRequest(it) }
                RebuildGuard.inRebuild.remove()
                if (marked != null) p.setResult(marked)
            } catch (t: Throwable) {
                RebuildGuard.inRebuild.remove()
                DshLog.e("Request.Builder.build hook failed", t)
            }
        })
    }
}

/**
 * 请求体改写的公共逻辑（第一层与第三层共用）。
 */
object RequestBodyRewriter {

    fun rewrite(bridge: OkHttpBridge, body: Any): Any? {
        if (RebuildGuard.inRebuild.get()) return null
        val cfg: HookConfig = ConfigClient.current()
        if (!cfg.enabled || !cfg.rewriteRequest) return null
        return try {
            // one-shot / duplex 的 body 只能被读一次，绝不能改写
            if (bridge.isOneShot(body) || bridge.isDuplex(body)) return null

            val ctObj = bridge.bodyContentType(body)
            val ct = ctObj?.toString()
            if (!cfg.matchesContentType(ct)) return null

            val bytes = bridge.readRequestBodyBytes(body) ?: return null
            if (bytes.isEmpty() || bytes.size > cfg.maxRewriteBytes) return null

            val chain = ChainCache.get(cfg)
            val ctx = TransformContext(
                config = cfg,
                role = "user",
                messageIndex = 0,
                totalMessages = 0,
                isFirstUserMessage = true,
                isLastUserMessage = true,
                direction = TransformContext.Direction.REQUEST
            )
            val result = MessageRewriter.rewrite(bytes, chain, ctx)
            if (!result.changed || result.bytes == null) return null

            val newBody = bridge.createRequestBody(result.bytes, ctObj) ?: return null
            DshLog.d("request body rewritten: ${bytes.size} -> ${result.bytes.size} bytes")
            newBody
        } catch (t: Throwable) {
            DshLog.e("rewrite request body failed", t)
            null
        }
    }
}
