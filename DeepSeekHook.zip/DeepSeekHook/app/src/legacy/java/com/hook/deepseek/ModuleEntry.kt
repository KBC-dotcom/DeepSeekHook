package com.hook.deepseek

import com.hook.deepseek.engine.ModuleCore
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * legacy Xposed 入口。
 * assets/xposed_init 里写的就是这个类名。
 */
class ModuleEntry : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val api = LegacyXHookApi()
        ModuleCore.start(api, lpparam.classLoader, lpparam.packageName, lpparam.processName)
    }
}
