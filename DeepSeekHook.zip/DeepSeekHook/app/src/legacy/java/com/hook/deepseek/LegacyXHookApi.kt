package com.hook.deepseek

import com.hook.deepseek.xapi.XHookApi
import com.hook.deepseek.xapi.XParam
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import java.lang.reflect.Method

/**
 * legacy Xposed API 适配器（de.robv.android.xposed:api:82）。
 *
 * 特点：框架自动调用原方法，before/after 之间就是原方法的执行；
 * 在 before 里调用 param.setResult() 可短路原方法。
 */
class LegacyXHookApi : XHookApi {

    override fun findClass(name: String, cl: ClassLoader?): Class<*>? = try {
        XposedHelpers.findClass(name, cl)
    } catch (t: Throwable) {
        null
    }

    override fun hookAllMethods(
        clazz: Class<*>,
        name: String,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Int {
        val hooks = XposedBridge.hookAllMethods(clazz, name, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cb = before ?: return
                cb(XParam(param.member, param.thisObject, param.args, true))
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                val cb = after ?: return
                val p = XParam(param.member, param.thisObject, param.args, false, param.result, param.throwable)
                cb(p)
                if (p.isResultSet()) param.result = p.result
                if (p.throwable != null) param.throwable = p.throwable
            }
        })
        return hooks.size
    }

    override fun hookAllConstructors(
        clazz: Class<*>,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Int {
        val hooks = XposedBridge.hookAllConstructors(clazz, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cb = before ?: return
                cb(XParam(param.member, param.thisObject, param.args, true))
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                val cb = after ?: return
                val p = XParam(param.member, param.thisObject, param.args, false, param.result, param.throwable)
                cb(p)
                if (p.isResultSet()) param.result = p.result
                if (p.throwable != null) param.throwable = p.throwable
            }
        })
        return hooks.size
    }

    override fun hookMethod(
        method: Method,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Boolean = try {
        XposedBridge.hookMethod(method, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                val cb = before ?: return
                cb(XParam(param.member, param.thisObject, param.args, true))
            }

            override fun afterHookedMethod(param: MethodHookParam) {
                val cb = after ?: return
                val p = XParam(param.member, param.thisObject, param.args, false, param.result, param.throwable)
                cb(p)
                if (p.isResultSet()) param.result = p.result
                if (p.throwable != null) param.throwable = p.throwable
            }
        })
        true
    } catch (t: Throwable) {
        false
    }

    override fun setStaticObjectField(clazz: Class<*>, name: String, value: Any?): Boolean = try {
        XposedHelpers.setStaticObjectField(clazz, name, value)
        true
    } catch (t: Throwable) {
        false
    }

    override fun log(message: String) {
        XposedBridge.log("[DSH] $message")
    }

    override fun logError(message: String, t: Throwable) {
        XposedBridge.log("[DSH] $message : ${t.javaClass.name}: ${t.message}")
    }
}
