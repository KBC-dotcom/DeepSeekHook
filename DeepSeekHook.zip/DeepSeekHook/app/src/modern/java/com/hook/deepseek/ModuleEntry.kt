package com.hook.deepseek

import com.hook.deepseek.engine.ModuleCore
import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModuleInterface

/**
 * libxposed 新版 API 入口（>=102）。
 *
 * 说明：本类假设 XposedModuleInterface 继承 XposedInterface，
 * 且 onPackageLoaded(PackageLoadedParam) 是模块加载回调。
 * 若你使用的 libxposed 版本签名不同，请对照 docs/MODERN_API_NOTES.md 调整。
 */
class ModuleEntry : XposedModuleInterface {

    override fun onPackageLoaded(param: XposedModuleInterface.PackageLoadedParam) {
        val api = ModernXHookApi(this as XposedInterface)
        ModuleCore.start(api, param.getClassLoader(), param.getPackageName(), null)
    }
}
