package com.hook.deepseek

import com.hook.deepseek.xapi.XHookApi
import com.hook.deepseek.xapi.XParam
import io.github.libxposed.api.XposedInterface
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

/**
 * libxposed 新版 API 适配器（io.github.libxposed:api，>=102）。
 *
 * 与 legacy 的差异：现代 API 不再由框架自动调用原方法，
 * 而是把原方法交给 Hooker，由 Hooker 决定何时调用、返回什么。
 *
 * ！！本文件假设的 API 形态（若你使用的 libxposed 版本签名不同，只需改这一处）：
 *   interface XposedInterface {
 *       interface Hooker {
 *           Object hook(Method origin, Object thisObject, Object[] args) throws Throwable;
 *       }
 *       <T extends Hooker> T hook(Method origin, T hooker);   // 实例重载
 *   }
 * 详见 docs/MODERN_API_NOTES.md
 */
class ModernXHookApi(private val xposed: XposedInterface) : XHookApi {

    override fun findClass(name: String, cl: ClassLoader?): Class<*>? = try {
        if (cl == null) Class.forName(name, false, null) else Class.forName(name, false, cl)
    } catch (t: Throwable) {
        null
    }

    override fun hookAllMethods(
        clazz: Class<*>,
        name: String,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Int {
        var count = 0
        for (m in clazz.declaredMethods) {
            if (m.name != name) continue
            if (hookMethod(m, before, after)) count++
        }
        return count
    }

    override fun hookAllConstructors(
        clazz: Class<*>,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Int {
        var count = 0
        for (c in clazz.declaredConstructors) {
            if (hookConstructor(c, before, after)) count++
        }
        return count
    }

    override fun hookMethod(
        method: Method,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Boolean = try {
        xposed.hook(method, object : XposedInterface.Hooker {
            override fun hook(origin: Method, thisObject: Any?, args: Array<Any?>?): Any? {
                return runHook(origin, thisObject, args, before, after)
            }
        })
        true
    } catch (t: Throwable) {
        false
    }

    /**
     * 构造器 Hook：现代 API 的 hook 入口签名以 Method 为主，
     * 这里用 Executable 语义做一次兼容尝试，失败则跳过（业务层不依赖构造器 Hook 的结果）。
     */
    private fun hookConstructor(
        ctor: java.lang.reflect.Constructor<*>,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Boolean = try {
        val hookMethod = XposedInterface::class.java.methods.firstOrNull { m ->
            m.name == "hook" && m.parameterTypes.size == 2 &&
                m.parameterTypes[0].isAssignableFrom(ctor.javaClass)
        } ?: return false
        val hookerType = hookMethod.parameterTypes[1]
        if (!hookerType.isInterface) return false
        val hooker = java.lang.reflect.Proxy.newProxyInstance(
            hookerType.classLoader,
            arrayOf(hookerType)
        ) { _, method, args ->
            if (method.name != "hook") return@newProxyInstance null
            @Suppress("UNCHECKED_CAST")
            runHook(
                args?.get(0) as? Method,
                args?.get(1),
                args?.get(2) as? Array<Any?>?,
                before,
                after
            )
        }
        hookMethod.invoke(xposed, ctor, hooker)
        true
    } catch (t: Throwable) {
        false
    }

    /**
     * 统一的 Hook 执行流程：
     *   before -> 调用原方法 -> after -> 返回（可能被改写的）结果
     */
    private fun runHook(
        origin: Method,
        thisObject: Any?,
        args: Array<Any?>?,
        before: ((XParam) -> Unit)?,
        after: ((XParam) -> Unit)?
    ): Any? {
        if (before != null) {
            val p = XParam(origin, thisObject, args, true)
            before(p)
            if (p.isResultSet()) return p.result
            if (p.throwable != null) throw p.throwable!!
        }

        var result: Any? = null
        var err: Throwable? = null
        try {
            result = origin.invoke(thisObject, *(args ?: emptyArray()))
        } catch (t: Throwable) {
            err = if (t is InvocationTargetException && t.targetException != null) t.targetException else t
        }

        if (after != null) {
            val p = XParam(origin, thisObject, args, false, result, err)
            after(p)
            if (p.isResultSet()) return p.result
            if (p.throwable != null) throw p.throwable!!
        }

        if (err != null) throw err
        return result
    }

    override fun setStaticObjectField(clazz: Class<*>, name: String, value: Any?): Boolean = try {
        val f = clazz.getDeclaredField(name)
        f.isAccessible = true
        f.set(null, value)
        true
    } catch (t: Throwable) {
        false
    }

    override fun log(message: String) {
        try {
            xposed.log("[DSH] $message")
        } catch (t: Throwable) {
            android.util.Log.i("DeepSeekHook", message)
        }
    }

    override fun logError(message: String, t: Throwable) {
        log("$message : ${t.javaClass.name}: ${t.message}")
    }
}
