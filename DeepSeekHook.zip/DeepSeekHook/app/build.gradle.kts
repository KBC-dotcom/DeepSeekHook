plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hook.deepseek"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hook.deepseek"
        minSdk = 27
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    // 两个 flavor 共享同一份业务代码（src/main），只替换 Xposed API 适配层：
    //   legacy : de.robv.android.xposed  (IXposedHookLoadPackage + XC_MethodHook)
    //   modern : io.github.libxposed.api  (XposedModuleInterface) —— 设计文档要求的 >=102
    flavorDimensions += "api"
    productFlavors {
        create("legacy") {
            dimension = "api"
            buildConfigField("String", "API_FLAVOR", "\"legacy\"")
            dependencies {
                compileOnly("de.robv.android.xposed:api:82")
            }
        }
        create("modern") {
            dimension = "api"
            buildConfigField("String", "API_FLAVOR", "\"modern\"")
            dependencies {
                compileOnly("io.github.libxposed:api:${providers.gradleProperty("libxposedApiVersion").get()}")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            // 保留 META-INF/xposed/* （modern flavor 的模块声明）
            excludes += setOf("META-INF/*.version", "META-INF/DEPENDENCIES")
        }
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // 刻意不引入 OkHttp / Okio：本模块运行在目标进程内，
    // 一旦把 okhttp 打进 APK 会与目标 App 自带的 okhttp 版本冲突。
    // 所有 OkHttp/Okio 交互一律走反射（见 engine/OkHttpBridge.kt）。
    // 也不引入 androidx：UI 使用 framework 原生控件，零第三方运行时依赖。
}
