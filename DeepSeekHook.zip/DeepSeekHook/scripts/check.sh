#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================
#  DeepSeekHook —— 装完自检
#  用法（在 Termux 里）：bash check.sh
#  检查三件事：模块装没装 / 配置通道通不通 / 钩子有没有真的注入
# ==============================================================
set -uo pipefail

BOLD=$'\033[1m'; GRN=$'\033[32m'; YEL=$'\033[33m'; RED=$'\033[31m'; NC=$'\033[0m'
ok(){   printf "${GRN}  [OK]${NC} %s\n" "$*"; }
warn(){ printf "${YEL}  [!]${NC} %s\n" "$*"; }
bad(){  printf "${RED}  [X]${NC} %s\n" "$*"; }
sec(){  printf "\n${BOLD}== %s ==${NC}\n" "$*"; }

PKG=com.hook.deepseek
TARGET=com.deepseek.chat

sec "1. 模块 App 是否已安装"
if pm list packages 2>/dev/null | grep -q "package:$PKG"; then
  ok "$PKG 已安装"
else
  bad "$PKG 没装 —— 先用文件管理安装 ~/Download/DeepSeekHook.apk"
fi

sec "2. 配置通道（模块 App -> 目标进程）"
OUT="$(content query --uri content://$PKG.provider/config 2>&1 | head -c 400)"
if echo "$OUT" | grep -q '"enabled"'; then
  ok "Provider 能读到配置："
  echo "$OUT" | sed 's/^/      /'
else
  bad "读不到配置：$OUT"
  warn "如果模块 App 刚装上，这里可能还不通，属正常"
fi

sec "3. 钩子是否注入目标进程"
LOG=/data/data/$TARGET/files/dsh/hook.log
if su -c "test -f $LOG" 2>/dev/null; then
  ok "找到注入日志 $LOG"
  echo "  ---- 最近 25 行 ----"
  su -c "tail -n 25 $LOG" 2>/dev/null | sed 's/^/      /'
  if su -c "grep -q 'hooks installed' $LOG" 2>/dev/null; then
    ok "检测到 'hooks installed' —— 模块已成功注入"
  else
    warn "日志里还没有 'hooks installed'，请强制停止 DeepSeek 后重开"
  fi
else
  bad "没有找到 $LOG —— 模块还没注入"
  warn "排查：LSPosed -> 模块 -> 打开开关 -> 作用域只勾 DeepSeek -> 强停 DeepSeek 重开"
fi

sec "结论"
echo "  下一步：打开 DeepSeek Hook 模块 App，设好术语表/前缀模板 -> 保存 ->"
echo "          强制停止 DeepSeek -> 重新打开 -> 发一条消息试"
