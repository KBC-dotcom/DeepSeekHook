#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================
#  DeepSeekHook —— 安卓手机端一键编译
#  用法（在 Termux 里）：bash build-on-phone.sh
#  脚本会自己：装依赖 -> 下 SDK/Gradle -> 找工程 -> 处理 aapt2 -> 编译 -> 给出安装指引
# ==============================================================
set -uo pipefail

BOLD=$'\033[1m'; DIM=$'\033[2m'; GRN=$'\033[32m'; YEL=$'\033[33m'; RED=$'\033[31m'; BLU=$'\033[36m'; NC=$'\033[0m'
step(){ printf "\n${BOLD}${BLU}==>${NC}${BOLD} %s${NC}\n" "$*"; }
ok(){   printf "${GRN}  [OK]${NC} %s\n" "$*"; }
warn(){ printf "${YEL}  [!]${NC} %s\n" "$*"; }
die(){  printf "${RED}  [X]${NC} %s\n" "$*" >&2; exit 1; }

SDK="$HOME/android-sdk"
GRADLE_VER="8.7"
GRADLE_HOME="$HOME/gradle-$GRADLE_VER"
BT="34.0.0"

# ---------------------------------------------------------------- 0. 环境
step "0/8 检查环境"
if [ -z "${PREFIX:-}" ] || [ ! -d "${PREFIX:-/nonexistent}" ]; then
  die "这个脚本必须在 Termux 里运行。
     请先装 Termux（不要装 Play 商店版）：https://f-droid.org/packages/com.termux/"
fi
ok "Termux: $PREFIX"

# ---------------------------------------------------------------- 1. 依赖
step "1/8 安装依赖（openjdk-17 / unzip / wget / curl）"
pkg update -y >/dev/null 2>&1 || warn "pkg update 没成功，继续尝试"
pkg install -y openjdk-17 unzip wget curl >/dev/null 2>&1 || die "依赖安装失败，检查手机网络"

# 不同版本的 Termux 把 JDK 装在不同位置（lib/jvm/openjdk-17、opt/openjdk ...），
# 这里自动探测，别写死路径
detect_java_home() {
  for c in "$PREFIX/lib/jvm/openjdk-17" "$PREFIX/opt/openjdk" "$PREFIX/opt/openjdk-17" "$PREFIX/lib/jvm/openjdk"; do
    [ -x "$c/bin/java" ] && { printf '%s' "$c"; return 0; }
  done
  for c in "$PREFIX"/lib/jvm/*/ "$PREFIX"/opt/*/; do
    [ -x "${c}bin/java" ] && { printf '%s' "${c%/}"; return 0; }
  done
  local jb hd
  jb="$(readlink -f "$(command -v java 2>/dev/null)" 2>/dev/null)"
  if [ -n "$jb" ]; then
    hd="$(dirname "$(dirname "$jb")")"
    [ -x "$hd/bin/java" ] && { printf '%s' "$hd"; return 0; }
  fi
  return 1
}

JAVA_HOME="$(detect_java_home || true)"
if [ -z "$JAVA_HOME" ]; then
  warn "没找到 JDK 17，改装 openjdk-21 再试"
  pkg install -y openjdk-21 >/dev/null 2>&1 || true
  JAVA_HOME="$(detect_java_home || true)"
fi
[ -n "$JAVA_HOME" ] || die "找不到 JDK。手动执行：pkg install openjdk-17 && ls \$PREFIX/lib/jvm \$PREFIX/opt"
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"
ok "JAVA_HOME: $JAVA_HOME"
ok "JDK: $(java -version 2>&1 | head -n1)"

# ---------------------------------------------------------------- 2. SDK
step "2/8 准备 Android SDK（platform-34 / build-tools $BT）"
mkdir -p "$SDK/cmdline-tools"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  cd "$SDK/cmdline-tools"
  warn "正在下载 Android SDK 命令行工具（约 130 MB）..."
  wget -q -O cmdline.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip \
    || die "SDK 下载失败，检查网络"
  unzip -q cmdline.zip && rm -f cmdline.zip
  if [ -d cmdline-tools ]; then mv cmdline-tools latest; fi
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$PATH"

if [ ! -d "$SDK/platforms/android-34" ] || [ ! -d "$SDK/build-tools/$BT" ]; then
  warn "正在接受协议并安装 SDK 组件（约 700 MB）..."
  timeout 240 sh -c 'yes | sdkmanager --licenses >/dev/null 2>&1' || true
  sdkmanager "platform-tools" "platforms;android-34" "build-tools;$BT" \
    || die "SDK 组件安装失败（若上面报 JAVA_HOME 错误，说明 JDK 目录探测失败）
   当前 JAVA_HOME=$JAVA_HOME
   手动核对：ls \$PREFIX/lib/jvm \$PREFIX/opt"
fi
ok "SDK 就绪：$SDK"

# ---------------------------------------------------------------- 3. Gradle
step "3/8 准备 Gradle $GRADLE_VER"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  cd "$HOME"
  warn "正在下载 Gradle $GRADLE_VER（约 130 MB）..."
  wget -q -O gradle.zip "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip" \
    || die "Gradle 下载失败，检查网络"
  unzip -q gradle.zip && rm -f gradle.zip
fi
export PATH="$GRADLE_HOME/bin:$PATH"
ok "Gradle: $(gradle --version 2>/dev/null | grep -m1 '^Gradle' || echo "$GRADLE_VER")"

# ---------------------------------------------------------------- 4. 找工程
step "4/8 定位工程目录"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"
PROJ=""
if   [ -f "$SELF_DIR/build.gradle.kts" ];    then PROJ="$SELF_DIR"
elif [ -f "$SELF_DIR/../build.gradle.kts" ]; then PROJ="$(cd "$SELF_DIR/.." && pwd)"
fi
if [ -z "$PROJ" ]; then
  for d in "$HOME/DeepSeekHook" \
           "/sdcard/Download/DeepSeekHook" \
           "/storage/emulated/0/Download/DeepSeekHook" \
           "/storage/emulated/0/MT2/mcp/DeepSeekHook"; do
    [ -f "$d/build.gradle.kts" ] && { PROJ="$d"; break; }
  done
fi
if [ -z "$PROJ" ]; then
  for z in "$HOME/DeepSeekHook.zip" \
           "/sdcard/Download/DeepSeekHook.zip" \
           "/storage/emulated/0/Download/DeepSeekHook.zip" \
           "/storage/emulated/0/MT2/mcp/DeepSeekHook.zip"; do
    if [ -f "$z" ]; then
      warn "找到压缩包：$z"
      cd "$HOME" && unzip -q -o "$z" && PROJ="$HOME/DeepSeekHook" && break
    fi
  done
fi
[ -n "$PROJ" ] || die "找不到工程。
     请把 DeepSeekHook.zip 放到 $HOME 或 /sdcard/Download/ 后重跑本脚本。
     （本机上它应该在 /storage/emulated/0/MT2/mcp/DeepSeekHook.zip）"
cd "$PROJ"
ok "工程目录：$PROJ"

# ---------------------------------------------------------------- 5. aapt2
step "5/8 检查 aapt2（手机编译的头号坑）"
AAPT2=""
if [ -x "$SDK/build-tools/$BT/aapt2" ] && "$SDK/build-tools/$BT/aapt2" version >/dev/null 2>&1; then
  AAPT2="$SDK/build-tools/$BT/aapt2"
  ok "SDK 自带 aapt2 可直接用"
else
  warn "SDK 自带的 aapt2 是 x86_64 版，本机 ARM64 跑不了（会报 Exec format error）"
  for c in "$PREFIX/bin/aapt2" \
           "$PREFIX/share/android-sdk/build-tools/$BT/aapt2" \
           "$HOME/aapt2" "$SELF_DIR/aapt2"; do
    if [ -x "$c" ] && "$c" version >/dev/null 2>&1; then AAPT2="$c"; break; fi
  done
  if [ -z "$AAPT2" ]; then
    warn "正在尝试从 Termux 软件源找 ARM 版 aapt2 ..."
    pkg install -y tur-repo >/dev/null 2>&1 || true
    pkg install -y aapt2   >/dev/null 2>&1 || true
    if [ -x "$PREFIX/bin/aapt2" ] && "$PREFIX/bin/aapt2" version >/dev/null 2>&1; then
      AAPT2="$PREFIX/bin/aapt2"
    fi
  fi
  if [ -z "$AAPT2" ] && command -v su >/dev/null 2>&1; then
    warn "尝试从已安装的 AndroidIDE 里借用 ARM 版 aapt2 ..."
    CAND="$(su -c 'find /data/data/com.itsaky.androidide /data/data/com.termux -type f -name aapt2 2>/dev/null | head -n 8' 2>/dev/null || true)"
    for c in $CAND; do
      if su -c "'$c' version" >/dev/null 2>&1; then AAPT2="$c"; break; fi
    done
  fi
  if [ -n "$AAPT2" ]; then
    ok "找到 ARM 版 aapt2：$AAPT2"
    grep -q 'aapt2FromMavenOverride' gradle.properties 2>/dev/null \
      || echo "android.aapt2FromMavenOverride=$AAPT2" >> gradle.properties
    ok "已写入 gradle.properties"
  else
    die "没找到 ARM64 的 aapt2（手机编译最常见的坑）。
   两条退路，任选其一：

   A) 装 AndroidIDE（F-Droid 搜 com.itsaky.androidide），它内置 ARM 原生 aapt2。
      装完直接重跑本脚本即可（脚本会自动去 AndroidIDE 里找 aapt2），
      或者在 AndroidIDE 里直接打开 ~/DeepSeekHook 编译。

   B) 云编译（最稳，5 分钟出 APK）：
      把 DeepSeekHook.zip 传到 GitHub 新建的仓库 ->
      Actions -> Build workflow -> Run workflow ->
      完成后在 Artifacts 下载 DeepSeekHook-apk。"
  fi
fi

# ---------------------------------------------------------------- 6. 编译
step "6/8 开始编译（首次要下载依赖，约 10~30 分钟，请勿中断/息屏）"
echo "sdk.dir=$SDK" > local.properties
if ! gradle assembleLegacyDebug; then
  die "编译失败。请把上面最后 30 行错误信息发给我。"
fi

# ---------------------------------------------------------------- 7. 产物
step "7/8 编译产物"
APK="$(find app/build/outputs/apk -name '*.apk' 2>/dev/null | head -n1)"
[ -n "$APK" ] || die "编译似乎成功但没找到 APK"
ok "APK：$PROJ/$APK"
mkdir -p "$HOME/Download"
cp -f "$APK" "$HOME/Download/DeepSeekHook.apk" 2>/dev/null && ok "已复制到：~/Download/DeepSeekHook.apk"

# ---------------------------------------------------------------- 8. 安装
step "8/8 安装"
if [ -x "$SDK/platform-tools/adb" ] && "$SDK/platform-tools/adb" devices 2>/dev/null | grep -q "device$"; then
  "$SDK/platform-tools/adb" install -r "$APK" && ok "已通过 adb 安装"
else
  ok "请用「文件管理 -> Download -> DeepSeekHook.apk」点开安装（需允许“安装未知来源应用”）"
fi

cat <<'EOF'

=================== 下一步 ===================
1) 文件管理 -> Download -> DeepSeekHook.apk -> 安装
2) LSPosed -> 模块 -> 打开「DeepSeek Hook」
   -> 点进去，作用域【只勾】DeepSeek (com.deepseek.chat)
3) 设置 -> 应用 -> DeepSeek -> 强行停止 -> 重新打开
4) 验证：adb logcat | grep DSH
   应看到 [DSH] hooks installed: okhttp=true ...
==============================================
EOF
