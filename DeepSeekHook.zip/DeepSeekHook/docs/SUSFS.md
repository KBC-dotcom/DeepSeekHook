# 与 SUSFS 配合

模块本身只在**用户态**做伪装。内核层痕迹（`/proc` 下多出来的挂载点、magisk 挂载、
真实的 `uname` 字符串、隐藏的 root 相关路径）必须由 **SUSFS** 处理，
因为只有内核能真正让这些路径「不存在」。

---

## 1. 需要准备什么

1. 内核已合入 SUSFS 补丁，**版本 ≥ 1.5.2**（低版本的 susfs4ksu 用户态助手接口不同）。
2. 已刷入 `susfs4ksu-module`（提供 `ksu_susfs` 用户态助手与模块配置文件）。
3. KernelSU 以 LKM 模式修补 `init_boot.img` 刷入（K80 内核线 6.1.75-android14）。

> ⚠️ 不同 susfs4ksu 版本的模块目录结构、配置文件名、助手命令行参数**并不一致**。
> 本工程不去猜测具体参数——请以你本地 susfs4ksu 模块目录里的实际文件为准。

---

## 2. 需要在 SUSFS 侧配置的三件事

| 项目 | 作用 | 典型配置位置 |
|---|---|---|
| `SUS_PATH` | 隐藏 `/data/adb`、`/data/local/tmp` 之类路径的存在性 | susfs4ksu 模块配置文件 / 内核 cmdline |
| 挂载隐藏 | 把 magisk / 模块的 overlay 挂载点对目标进程隐藏 | 内核 cmdline 或模块配置 |
| uname 伪装 | 让 `uname` 返回伪造的 kernel release | 内核 cmdline 或模块配置 |

对应到本模块的用户态通道：

* **路径隐藏** → SUSFS 的 `SUS_PATH`（内核侧）。模块无法伪造 `File.exists()` 这类系统调用。
* **uname** → 模块钩了 `android.system.Os.uname()`（Java 侧），
  但**应用自己的 .so 里直接调 libc `uname()` 仍会拿到真值**，只能靠 SUSFS 内核侧改。
* **`/proc/self/mounts` 读取** → 同样是内核侧，模块不处理。

---

## 3. 怎么确认 SUSFS 生效了

在目标 App 进程里检查（而不是在 shell 里检查，shell 可能被单独放行）：

```bash
# 用 root shell 进入 DeepSeek 进程的 mount namespace
su -c 'nsenter -t $(pidof com.deepseek.chat) -m -- ls /data/adb'
su -c 'nsenter -t $(pidof com.deepseek.chat) -m -- cat /proc/self/mounts | grep -i magisk'
su -c 'nsenter -t $(pidof com.deepseek.chat) -m -- uname -a'
```

如果这三条里还能看到 magisk / `/data/adb` / 真实 kernel 版本，说明 SUSFS 侧还没配好，
此时模块再怎么改用户态也补不上。

---

## 4. 模块侧的边界

模块在用户态做了这些（见 `engine/conceal/Conceal.kt`）：

* 包管理器枚举过滤（root 管理器 / LSPosed 管理器的包名）
* `android.os.Build` 静态字段覆盖（**Android 12+ 部分字段写不进去**）
* `SystemProperties.get` / `native_get` / `getInt` / `getLong` / `getBoolean` 覆盖
* `android.system.Os.uname()` 覆盖
* 屏蔽 App 进程里对 `de.robv.android.xposed.*` / `org.lsposed.*` 等类的加载

模块**不**处理：文件存在性、挂载表、原生 `uname`、原生 `__system_property_get`。
这些全部依赖 SUSFS（内核）或 Zygisk/Frida 级别的 libc hook。
