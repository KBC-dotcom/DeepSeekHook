# modern flavor（libxposed API）适配说明

本工程生成于无网络沙箱，**无法联网核对 libxposed 的最新 API 文档**。
下面的签名是本工程**假设**的形态。如果与你本地的 libxposed 版本不一致，
只需要改 `app/src/modern/java/com/hook/deepseek/` 下的两个文件，业务代码一行都不用动。

---

## 1. 本工程假设的 API

```java
package io.github.libxposed.api;

public interface XposedInterface {
    interface Hooker {
        Object hook(Method origin, Object thisObject, Object[] args) throws Throwable;
    }

    <T extends Hooker> T hook(Method origin, T hooker);   // 实例重载
    void log(String message);
}

public interface XposedModuleInterface extends XposedInterface {
    void onPackageLoaded(PackageLoadedParam param);

    interface PackageLoadedParam {
        String getPackageName();
        ClassLoader getClassLoader();
        ApplicationInfo getApplicationInfo();
        boolean isFirstPackage();
    }
}
```

对应到本工程：

* `app/src/modern/java/com/hook/deepseek/ModuleEntry.kt`
  * `class ModuleEntry : XposedModuleInterface`
  * `override fun onPackageLoaded(param: XposedModuleInterface.PackageLoadedParam)`
  * `param.getPackageName()` / `param.getClassLoader()`
* `app/src/modern/java/com/hook/deepseek/ModernXHookApi.kt`
  * `object : XposedInterface.Hooker { override fun hook(origin, thisObject, args): Any? }`
  * `xposed.hook(method, hooker)`

---

## 2. 如果签名不一样，改哪里

| 实际情况 | 改法 |
|---|---|
| 只有 `hook(Method, Class<T>)` 重载，没有实例重载 | 把 `ModernXHookApi.hookMethod` 里的匿名 `XposedInterface.Hooker` 提成一个 `private class ModernHooker(...) : XposedInterface.Hooker`，然后改成 `xposed.hook(method, ModernHooker::class.java)` |
| `Hooker.hook` 的参数是 `(Method, Object, Object[])` 之外的形状 | 只改 `ModernXHookApi.runHook` 的形参声明；`runHook` 内部逻辑（before → 调原方法 → after → 返回改写结果）与具体 API 无关 |
| `XposedModuleInterface` 不继承 `XposedInterface` | `ModuleEntry` 里 `ModernXHookApi(this as XposedInterface)` 的强转会编译不过；此时框架通常会在构造器里把 `XposedInterface` 传进来，改成构造器注入即可 |
| 框架要求在构造器里接 `XposedInterface` | 改成 `class ModuleEntry(private val base: XposedInterface) : XposedModuleInterface { ... }`，具体签名以你本地 API 为准 |
| 框架需要 `onSystemServerLoaded` | 按接口要求补一个空实现 |
| 模块入口声明文件不是 `META-INF/xposed/java_init.list` | 改 `app/src/modern/resources/META-INF/xposed/` 下的文件名/内容；`scope.list` 同理 |

---

## 3. 如果只想先跑起来

**legacy flavor 不依赖任何这些假设**：

```bash
./gradlew assembleLegacyDebug
```

`de.robv.android.xposed:api:82` 是稳定多年的公开 API，`assets/xposed_init` + 清单里的
`xposedscope` meta-data 是 LSPosed 一直支持的加载方式。
功能上两个 flavor **完全等价**（都走 `engine/` 下的同一套实现），
差别只在于 modern 不会被框架标记为「deprecated API 模块」。

---

## 4. flavor 与资源文件的关系

| 文件 | legacy | modern |
|---|---|---|
| 入口类声明 | `src/legacy/assets/xposed_init` | `src/modern/resources/META-INF/xposed/java_init.list` |
| 作用域声明 | `src/legacy/assets/xposed_scope` + 清单 meta-data | `src/modern/resources/META-INF/xposed/scope.list` + 清单 meta-data |
| 入口实现 | `src/legacy/java/.../ModuleEntry.kt` | `src/modern/java/.../ModuleEntry.kt` |

两个 flavor 的入口类**同名同包**（`com.hook.deepseek.ModuleEntry`），
由 Gradle 的 flavor source set 决定编译哪一个，因此不存在同名类冲突。
