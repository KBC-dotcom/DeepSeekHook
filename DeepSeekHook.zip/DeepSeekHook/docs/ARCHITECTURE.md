# 架构说明：设计文档 → 代码的逐条映射

本文按原设计文档的六个小节，逐一说明落地位置、做法，以及**与文档的偏差及原因**。

---

## 一、K80 的 KernelSU / LSPosed 环境配置

| 文档要求 | 落地方式 |
|---|---|
| LSPosed 侧建议 libxposed API ≥ 102 | `modern` flavor，依赖 `io.github.libxposed:api`，版本号在 `gradle.properties` 的 `libxposedApiVersion` |
| 作用域只写 `com.deepseek.chat`，不加模块自身包名 | `AndroidManifest.xml` 的 `xposedscope` meta-data + `src/legacy/assets/xposed_scope` + `src/modern/resources/META-INF/xposed/scope.list`；`ModuleCore` 还会额外校验进程名，只处理主进程 |
| `exceptionMode=protective` | 文档写的这个字段并非 LSPosed 的标准 module.prop 字段，**无法直接配置**。等效做法是在代码层实现：所有 Hook 回调体都自己 `try/catch` 并降级（`DshLog.e` + 返回原值），任何一个钩子抛异常都不会把目标进程打崩。见 `engine/` 下各 Layer 的 `try { ... } catch (t: Throwable) { ... }` |
| SUSFS ≥ 1.5.2 + `susfs4ksu-module` | 内核侧，模块不负责。见 `docs/SUSFS.md` |

---

## 二、DeepSeek 客户端的攻击面

三层结构与代码一一对应：

* **CertificatePinner** → `engine/PinnerBypass.kt`
* **root / LSPosed 检测** → `engine/conceal/Conceal.kt`
* **OkHttp 网络层** → `engine/RequestLayer.kt`（请求入口）、`engine/ResponseLayer.kt`（响应出口）、`engine/ChainGuardLayer.kt`（链路兜底）

---

## 三、三层 Hook 架构

### 第一层：Request$Builder 请求体改写

文档要求：hookAllConstructors 批量挂载，在 afterHookedMethod 取 `body` 字段，读原始字节→改写→替换为新的 RequestBody.create。

**本实现**：

* `hookAllConstructors(Request.Builder)`：挂上了，但只用于打点（构造器里拿不到 body，
  body 是后续 `method()` 才设进去的）。
* `hookAllMethods(Request.Builder, "method")`（**before**）：这才是 body 进入 Builder 的
  最早位置，比构造器更合适。命中后直接把 `args[1]` 换成改写后的 body。
* `hookAllMethods(Request.Builder, "build")`（**after**）：兜底。取出已 build 的 Request，
  若未被标记则改写并用 `request.newBuilder().method(...).build()` 重建后返回。

**为什么不直接改 `body` 字段**：`Request.Builder.body` 在 OkHttp 4.x 是 Kotlin `internal var`，
访问器名字被 mangle 成 `getBody$okhttp` 之类，字段可见性在不同版本上不一致。
走 `method(String, RequestBody)` 这个**公开 API** 反射，跨 3.x/4.x/5.x 都稳定。

**FormBody / MultipartBody 统一处理**：先 `writeTo(okio.Buffer)` 读出原始字节，
改写后用**同样的 Content-Type**（含 multipart boundary）构造新的 RequestBody，
服务端看到的报文字节与结构完全一致。

**防递归**：重建 Request 会再次触发 `build()`，用 `RebuildGuard`（ThreadLocal）挡住。

### 第二层：ResponseBody 响应流拦截

文档要求：Hook `RealResponseBody` 的构造函数，因为 `create()` 的所有分支最终都汇聚于此；
拿到 BufferedSource 后用 `source.peek()` + `request(Long.MAX_VALUE)` + `snapshot()` 预读，
改写后重新包装为新的 ResponseBody 返回。

**本实现（与文档有一处关键偏差）**：

> Xposed **不允许替换构造器创建出来的实例**（`<init>` 的返回值就是 `this`），
> 所以「在构造器钩子里返回一个新的 ResponseBody」在 Xposed 框架下做不到。

于是拆成三个钩子：

| 钩子 | 作用 |
|---|---|
| `RealResponseBody.<init>`（after） | 抓 contentType / contentLength（文档说的「唯一稳定入口」） |
| `RealResponseBody.source()`（before） | 真正替换：返回改写后的字节流（`okio.Buffer`，它本身就是 `BufferedSource`） |
| `RealResponseBody.contentLength()`（after） | 让长度与改写后内容一致，否则 App 侧会读到错的长度 |

**流式稳定性**（文档第五节的重点）：

* 预读走 `peek()` 视图 + `snapshot()` 副本，**不消费原始流**；任何一步失败都原样回退，
  App 仍能拿到完整原始响应。
* 明确排除 `text/event-stream`（SSE），不预读、不改写，首块交付时机不受影响。
* 预读在 `source()` 的调用线程内**同步**完成，而不是文档建议的「后台线程 + 代理对象」。
  原因：后台线程读流、前台线程同时读同一个 okio buffer 是**数据竞争**（okio 的
  `BufferedSource` 不是线程安全的）；而 `source()` 之后 App 本来就要把这个 body 读完，
  同步读取的代价与 `body.string()` 相当，不改变背压语义。
* 没有修改 OkHttp `Dispatcher` 的线程池，不破坏 OkHttp 自身的并发契约。
* `Worker`（单线程队列）保留在 `engine/util/Worker.kt`，用于日志与配置刷新等
  **不会阻塞网络线程**的旁路任务。

### 第三层：RealInterceptorChain 兜底

`hookAllMethods(RealInterceptorChain, "proceed")`：

* before：检查 Request 是否已带「已改写」标记（用 `Request.tag`），
  没标记就地改写并替换 `args[0]`；
* after：对响应做最终形态校验（未知长度时打日志）。

标记用 `Request.tag(RewriteMarker::class.java, ...)`，因为 `Request.newBuilder()` 会复制 tag，
标记能跟着 Request 走完整条链路。

---

## 四、提示词语义保持改写策略链

文档要求：解析→变换→回写三段式；Transformer 只做确定性、语义保持的变换；
保持字段顺序和嵌套结构；任一环节失败整条链回退到原始字节。

**本实现**：

* **解析**：`core/json/Json.kt` 自带扫描器，产出带**字节区间**的 JSON 树。
  没有用 `org.json`（它不保顺序），也没有用 gson（会重排并改转义）。
* **变换**：`core/prompt/Transformers.kt`，链式串联
  （`WhitespaceNormalizer` → `TerminologyReplacer` → `ConditionalPrefixInjector`）。
  任一 Transformer 抛异常 → 整条链返回 `null` → 回退原始字节。
* **回写**：只替换目标字符串**字面量**的字节区间（`JsonText.splice`），
  其余原文按原样保留 → 字段顺序、缩进、转义风格都不变。
* **回写后再解析一次做结构校验**（`core/prompt/Rewriters.kt` 的 `StructureCheck`）：
  顶层成员数量/名称/顺序必须一致；未改写字段必须**逐字节相同**；
  改写字段只校验形状（类型一致、数组长度一致、非文本成员逐字节相同）。
  校验不过 → 回退原始字节。**绝不输出半改写状态。**

---

## 五、反检测与流式 Hook 线程稳定性

| 通道 | 实现 | 备注 |
|---|---|---|
| 包管理器过滤 | `Conceal.installPackageFilter` | `getPackageInfo` / `getApplicationInfo` 命中即抛 `NameNotFoundException`；`getInstalledPackages` / `getInstalledApplications` / `queryIntentActivities` / `resolveActivity` / `getPackagesForUid` 等从结果里剔除 |
| `Build` 静态字段 | `Conceal.installBuildSpoof` | Android 12+ 部分字段写不进去，会打印成功/失败计数 |
| `SystemProperties.get` | `Conceal.installSystemProperties` | 同时钩 `native_get` / `getInt` / `getLong` / `getBoolean`，四路返回值互相一致 |
| `__system_property_get` | — | **纯 Xposed 覆盖不到**（App 自带 so 直接调 libc 时）。需 Zygisk/Frida 级 libc hook |
| `uname` | `Conceal.installUname` | 钩 `android.system.Os.uname()`，改写 `Os.Uname` 的 5 个字段；内核层真值仍需 SUSFS |
| 类加载过滤 | `Conceal.installClassFilter` | **只对 App 自己的 ClassLoader 生效**（`p.thisObject !== appClassLoader` 就放行），避免把 LSPosed 框架自身的类加载也拦掉 |

线程稳定性小结见「第二层」中的说明。

---

## 六、合规与风险边界

见 `README.md` 第 8 节，以及模块内 `DshLog` 默认脱敏（不记录正文，只记长度与摘要）。
