# 在安卓手机上编译本工程

> 一句话版：装 **Termux**（F-Droid）+ **JDK 17** + **Android SDK cmdline-tools** + **Gradle 8.7**，
> 四样都在手机本地下载；卡点只有一个 —— **aapt2 架构**，下面第 5 节给解法。

---

## 0. 最省事：三步（推荐）

工程里带了 `scripts/build-on-phone.sh`，它把装依赖、下 SDK/Gradle、找工程、
处理 aapt2、编译、出 APK 全包了。你只需要：

**第 1 步** 装 Termux（F-Droid，**不要装 Play 商店版**）
→ https://f-droid.org/packages/com.termux/

**第 2 步** 把 `DeepSeekHook.zip` 放到手机任意位置（建议 `/sdcard/Download/`）。
本机上它已经在 `/storage/emulated/0/MT2/mcp/DeepSeekHook.zip`，脚本会自动去找。

**第 3 步** 打开 Termux，粘贴这一行回车：

```bash
bash /sdcard/Download/build-on-phone.sh
```

> 压缩包根目录就有一份 `build-on-phone.sh`（工程内也有一份 `DeepSeekHook/scripts/build-on-phone.sh`，
> 两个都能跑）。如果你还没解压 zip，脚本会自己从常见路径找并解压。
> 找不到脚本就把压缩包整个解压到 `/sdcard/Download/` 再跑上面那行。

跑完会直接告诉你 APK 在哪（并在有 adb 连接时自动安装），末尾还会打印 LSPosed 启用步骤。
**全程只需要看着它跑完，别中断。**

### 装完自检

工程里还带了一个自检脚本（压缩包根目录的 `check.sh`），装好并启用 LSPosed 之后跑一下：

```bash
bash /sdcard/Download/check.sh
```

它会依次检查：
1. 模块 App 装没装；
2. 配置通道通不通（能不能读到 Provider 里的配置 JSON）；
3. 钩子有没有真的注入目标进程（读 `/data/data/com.deepseek.chat/files/dsh/hook.log`，
   看到 `hooks installed` 即为成功）。

> 模块的日志除了 logcat，还会写进目标 App 自己的目录
> `/data/data/com.deepseek.chat/files/dsh/hook.log`，
> 因为普通 App 看不到别的应用的 logcat，这个文件用 root 一 cat 就有。
> 所以自检脚本需要 root（你手机已经 root 了，`su -c` 即可）。


---


---

## 1. 需要下载的软件（都在手机上完成）

| # | 软件 | 从哪下 | 备注 |
|---|---|---|---|
| 1 | **Termux** | F-Droid：https://f-droid.org/packages/com.termux/ | ⚠️ **不要装 Play 商店版**（已弃用，Android 11+ 上装不了依赖）。GitHub 备选：https://github.com/termux/termux-app/releases |
| 2 | **JDK 17** | Termux 仓库：`pkg install openjdk-17` | AGP 8.5 要求 JDK 17 |
| 3 | **Android SDK 命令行工具** | Google 官方：https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip | Termux 里 wget 即可，Java 写的，ARM 上能跑 |
| 4 | **Gradle 8.7** | https://services.gradle.org/distributions/gradle-8.7-bin.zip | Termux 里 wget 即可 |
| 5 | **aapt2（aarch64 版）** | 见第 5 节 | ⚠️ 这是唯一需要额外折腾的东西 |

> 可选：**AndroidIDE**（自带 ARM 原生 aapt2 + 完整 SDK，点点点就能编译）
> F-Droid：https://f-droid.org/packages/com.itsaky.androidide/

---

## 2. 复制粘贴命令（Termux 里逐段执行）

```bash
# ---- 基础环境 ----
pkg update -y && pkg install -y openjdk-17 unzip wget
export JAVA_HOME=$PREFIX/lib/jvm/openjdk-17
export PATH=$JAVA_HOME/bin:$PATH
java -version          # 应输出 17.x

# ---- Android SDK ----
mkdir -p $HOME/sdk/cmdline-tools && cd $HOME/sdk/cmdline-tools
wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip -q commandlinetools-linux-11076708_latest.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/sdk
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$PATH
yes | sdkmanager --licenses >/dev/null
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# ---- Gradle ----
cd $HOME && wget -q https://services.gradle.org/distributions/gradle-8.7-bin.zip && unzip -q gradle-8.7-bin.zip
export PATH=$HOME/gradle-8.7/bin:$PATH

# ---- 取工程并编译 ----
cp /storage/emulated/0/MT2/mcp/DeepSeekHook.zip $HOME/     # 工程在这台手机上
cd $HOME && unzip -q DeepSeekHook.zip && cd DeepSeekHook
echo "sdk.dir=$HOME/sdk" > local.properties
gradle assembleLegacyDebug
```

产物：`~/DeepSeekHook/app/build/outputs/apk/legacy/debug/app-legacy-debug.apk`

安装（不用 adb 也行）：
```bash
$HOME/sdk/platform-tools/adb install -r app/build/outputs/apk/legacy/debug/app-legacy-debug.apk
```
或者用文件管理器点开 APK 安装（需允许「安装未知来源应用」）。

> 建议把上面所有 `export` 写进 `~/.bashrc`，否则每次开 Termux 都要重敲。

---

## 3. 手机上的资源与耗时参考

| 项 | 大小/耗时 |
|---|---|
| JDK 17 | ~350 MB |
| SDK（platform 34 + build-tools 34） | ~700 MB |
| Gradle 8.7 | ~130 MB |
| Gradle 依赖 + AGP + Kotlin 插件（首次联网下载） | ~1.5 GB |
| 首次完整构建 | **10~30 分钟**（红米 K80 上正常，别中断） |
| 内存 | 峰值 2~4 GB，Termux 里建议先 `pkg install termux-api`? 不需要 |

装完依赖后二次构建只需 1~3 分钟。

---

## 4. 如果构建报错

| 报错 | 原因 | 处理 |
|---|---|---|
| `Failed to find Build Tools revision 34.0.0` | SDK 组件没装全 | 重跑 `sdkmanager "build-tools;34.0.0" "platforms;android-34"` |
| `SDK location not found` | 环境变量没设 | `export ANDROID_HOME=$HOME/sdk` + 写 `local.properties` |
| `Unsupported class file major version` | JDK 版本不对 | 确认 `java -version` 是 17 |
| `aapt2 ... Exec format error` | **架构不匹配，见第 5 节** | 换 aapt2 / 换 AndroidIDE / 走云编译 |
| `Could not resolve de.robv.android.xposed:api:82` | 网络或仓库问题 | 确认能访问 `https://api.xposed.info/`；或改用 `modern` flavor |
| 内存不足 / 被杀 | Gradle 吃内存 | `gradle assembleLegacyDebug -Dorg.gradle.jvmargs="-Xmx2048m"` |

---

## 5. 重点：aapt2 架构问题

**现象**：编译到资源处理阶段报
```
aapt2: cannot execute binary file: Exec format error
```
或
```
Failed to start aapt2 daemon
```

**原因**：Android Gradle Plugin 从 Maven 拉取 `com.android.tools.build:aapt2:<版本>:linux`，
这个包里只有 **x86_64** 的可执行文件（`sdkmanager` 装的 build-tools 里的 aapt2 同样是 x86_64）。
手机是 ARM64，跑不了 x86_64 二进制。

**三种解法（按推荐度）**

### 解法 1：用 AndroidIDE 编译（最省事）
AndroidIDE 自带 **ARM 原生** 的 aapt2 和完整 SDK，直接在 App 里：
1. 装 AndroidIDE（F-Droid）
2. 把工程解压到 `/sdcard/Download/DeepSeekHook`
3. AndroidIDE → 打开目录 → 等 Gradle 同步 → Build APK
> 若它自带的 Gradle 版本低于 8.7，把根 `build.gradle.kts` 里的 AGP 降到 `8.1.4`、
> `gradle-wrapper.properties` 改成 `gradle-8.0-bin.zip` 即可。

### 解法 2：Termux + 指定 ARM 版 aapt2
1. 拿到一个 aarch64 的 `aapt2`（AndroidIDE 的 SDK 目录里有现成的 ARM 版；
   或自己用 AOSP 源码编译；或某些 Termux 源提供）
2. 验证：`aapt2 version` 能打印版本号即说明架构对
3. 在工程 `gradle.properties` 里**取消注释**并改路径：
   ```properties
   android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2
   ```
4. 重新 `gradle assembleLegacyDebug`

### 解法 3：云端编译（完全绕开架构问题，手机只装 APK）
把工程推上 GitHub，用附带的 `.github/workflows/build.yml`：

```bash
cd ~/DeepSeekHook
git init && git add -A && git commit -m "init"
git remote add origin https://github.com/<你的账号>/DeepSeekHook.git
git push -u origin main
```
然后 GitHub 页面 → Actions → Build workflow → Run workflow → 完成后在 Artifacts 下载 APK。
工作流文件里第一条就是补上缺失的 `gradle-wrapper.jar`（沙箱产不出二进制）：
```yaml
- run: gradle wrapper --gradle-version 8.7
- run: ./gradlew assembleLegacyDebug
```

---

## 6. 手机编译 vs 云编译，怎么选

| | 手机本地（Termux） | 云端（GitHub Actions） |
|---|---|---|
| 首次配置 | 30 分钟起步 | 5 分钟 |
| 架构坑 | **有，必须解决 aapt2** | 没有 |
| 适合 | 想完全离线、经常改代码 | 只想尽快拿到 APK |
| 稳定性 | 内存/存储压力大时可能失败 | 稳 |

如果你只是想尽快把模块用起来 → **走云端**。
如果你要频繁改代码调试 → 装一次 AndroidIDE 或 Termux，长期反而更省事。
