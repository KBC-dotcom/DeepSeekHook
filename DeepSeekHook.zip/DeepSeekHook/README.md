# DeepSeekHook

面向 **红米 K80（KernelSU + LSPosed）** 环境下 DeepSeek 安卓客户端的 LSPosed 模块：
请求/响应改写 + root 环境隐藏。

> ⚠️ 仅用于**自有设备**上的安全研究与逆向工程学习。请求/响应改写可能违反目标服务
> 的用户协议并触发账号风控；证书固定绕过与 root 隐藏只应出现在**授权测试环境**。
> 本工程不得用于绕过付费功能或批量自动化滥用。详见文末「合规与风险边界」。

---

## 1. 它做了什么

| 层 | 位置 | 作用 |
|---|---|---|
| 证书固定绕过 | `engine/PinnerBypass.kt` | 把 `okhttp3.CertificatePinner.check` 变成空实现 |
| 第一层：请求体改写 | `engine/RequestLayer.kt` | `Request.Builder` 组装阶段改写 body（早于 App 自己的签名/加密拦截器） |
| 第二层：响应流拦截 | `engine/ResponseLayer.kt` | `RealResponseBody` 构造器抓元信息 + `source()` 处返回改写后的字节流 |
| 第三层：兜底 | `engine/ChainGuardLayer.kt` | `RealInterceptorChain.proceed` 处校验并改写漏网请求 |
| 提示词语义保持改写 | `core/prompt/` | 解析→变换→回写三段式，结构不匹配即回退原始字节 |
| 环境隐藏 | `engine/conceal/Conceal.kt` | 包管理器过滤 / `Build` 字段 / `SystemProperties` / `Os.uname` |

关键设计约束（与直接“抄一个 Xposed 教程”的差别）：

* **不打包 okhttp**。模块注入到目标进程后，APK 里再带一份 okhttp 会和目标 App 自带的
  版本打架（`okhttp3.internal.*` 包名冲突）。所以工程对 OkHttp/Okio 的访问**全部走反射**
  （`engine/OkHttpBridge.kt`），compile classpath 上没有任何 okhttp 制品。
* **不重排报文**。改写不做事后反序列化再序列化（那会丢字段顺序、改转义风格），
  而是用一个自带的保序 JSON 扫描器定位到目标字符串字面量，再按字节区间定点替换
  （`core/json/Json.kt`）。改完再重新解析一次做结构校验，不一致就整条链回退。
* **不破坏流式响应**。SSE（`text/event-stream`）明确排除在响应改写之外；
  读取用 `peek()` 视图 + `snapshot()` 副本，不消费原始流，失败时 App 仍能拿到完整原始响应。
* **零第三方运行时依赖**。UI 用 framework 原生控件，配置用 framework 自带的 `org.json`。

---

## 2. 环境要求

* Android 8.1+（minSdk 27）
* 已 root，且内核已刷入 **SUSFS ≥ 1.5.2** 补丁 + `susfs4ksu-module`（内核侧隐藏，见 `docs/SUSFS.md`）
* **LSPosed**（Zygisk 或 Riru 模式均可），模块作用域只勾 `com.deepseek.chat`
* 构建：Android Studio Hedgehog+ / AGP 8.5 / JDK 17

---

## 3. 构建

工程有两个 flavor，**业务代码完全共享**，只替换 Xposed API 适配层：## 3. 构建

> **不会编译？** 工程里自带一键脚本，在 Termux 里跑一行就完事：
> ```bash
> bash /sdcard/Download/DeepSeekHook/scripts/build-on-phone.sh
> ```
> 详见 `docs/BUILD_ON_PHONE.md`（含 aapt2 架构坑的说明与三条退路）。

工程有两个 flavor，**业务代码完全共享**，只替换 Xposed API 适配层：

| flavor | Xposed API | 说明 |
|---|---|---|
| `legacy` | `de.robv.android.xposed:api:82` | 兼容性最好，所有 LSPosed/Zygisk 框架都能用 |
| `modern` | `io.github.libxposed:api`（默认 102） | 设计文档要求的「不被标记为 deprecated API」路径 |

```bash
./gradlew assembleLegacyDebug     # -> app/build/outputs/apk/legacy/debug/
./gradlew assembleModernDebug     # -> app/build/outputs/apk/modern/debug/
```

> **gradle wrapper 说明**：本工程生成于无法产出二进制产物的沙箱，
> 因此 **没有附带 `gradle/wrapper/gradle-wrapper.jar` 与 `gradlew` 脚本**。
> 二选一即可：
> * 用 Android Studio 打开本目录（会自动补齐 wrapper），或
> * 本机装有 Gradle 8.7+ 时执行 `gradle wrapper --gradle-version 8.7` 生成后再构建。
>
> `gradle/wrapper/gradle-wrapper.properties` 已写好，指定 Gradle 8.7（AGP 8.5 要求 ≥ 8.7）。

`modern` flavor 依赖的 libxposed API 版本号在 `gradle.properties` 里：

```properties
libxposedApiVersion=102
```

> 本仓库在无网络沙箱中生成，**未能实际执行 Gradle 构建**。`modern` flavor 所依赖的
> libxposed API 签名请对照 `docs/MODERN_API_NOTES.md` 核对（那里列出了本工程假设的
> 签名与「如果不一样该改哪几行」）。

---

## 4. 安装与启用

1. 装好 KernelSU + LSPosed，确认 LSPosed 已激活。
2. 安装 APK（`legacy` 或 `modern` 均可）。
3. LSPosed → 模块 → 启用「DeepSeek Hook」→ 作用域**只勾 `com.deepseek.chat`**
   （模块自身包名不要勾，避免自己注入自己）。
4. 打开模块 App 调参 → 保存 → 强制停止 DeepSeek 再启动。

配置通过模块 App 的 `ContentProvider`（`content://com.hook.deepseek.provider/config`）
传给目标进程，读取带 2s 缓存，**改完配置约 2 秒生效**，无需重启目标 App
（唯一例外：`Build` 静态字段伪装是在模块加载时写字段的，改完要重启目标 App）。

---

## 5. 可配置项

| 配置 | 默认 | 说明 |
|---|---|---|
| 启用模块 | 开 | 总开关 |
| 绕过证书固定 | 开 | `CertificatePinner.check` 空实现 |
| 放宽 hostname 校验 | 关 | 影响面更大，按需开 |
| 改写请求体 | 开 | 只处理 `messages[].role == "user"` 的 content |
| 改写响应体 | 关 | 处理 `choices[].message.content` 等 |
| 隐藏 root 管理器包名 | 开 | 命中即抛 `NameNotFoundException` / 从枚举结果里剔除 |
| 屏蔽 Xposed/LSPosed 类加载 | 开 | **只针对 App 自己的 ClassLoader**，不误伤框架自身 |
| 伪装 `Build` / `SystemProperties` / `uname` | 开 | 见下节「已知限制」 |
| 术语表 | 空 | 每行 `原文 => 译文`，ASCII 词条要求词边界，CJK 直接替换 |
| 前缀模板 | 空 | 可写 `{content}` 占位符；命中触发条件才注入，且幂等 |
| 调试日志 | 关 | 默认脱敏，只记录长度与摘要，不记录正文 |

新增自定义变换器：`core/prompt/` 里实现 `PromptTransformer`，
再到 `core/prompt/TransformerFactory.kt` 加一个分支即可，链的顺序由配置里的顺序决定。

---

## 6. 已知限制（重要，别踩坑）

1. **`Build` 静态字段在 Android 12+ 可能写不进去。**
   这些字段位于 boot image，ART 会标记为 trusted final，反射写入会被拒。
   模块会打印 `Build spoof: N written, M failed`，写失败的那几项就只能靠
   `SystemProperties` 侧通道和 SUSFS 兜底。**这一点无法靠纯 Xposed 绕过。**
2. **`__system_property_get` 的原生调用覆盖不到。**
   模块钩的是 `SystemProperties.get` 与 `SystemProperties.native_get`（Java 侧）。
   如果 App 用自带的 `.so` 直接调 libc 的 `__system_property_get`，纯 Xposed 无能为力，
   需要 Zygisk/Frida 级别的 libc hook。
3. **内核层痕迹（`/proc` 挂载点、magisk 挂载、真实 uname）只能靠 SUSFS。**
   模块只做用户态配合，详见 `docs/SUSFS.md`。
4. **响应改写默认关闭。** SSE 被明确排除；非 SSE 的 JSON 响应会在 `source()` 调用线程内
   同步读完，这与 App 自己 `body.string()` 的成本相当，但确实会推迟首个字节的交付。
5. **只处理主进程**（`com.deepseek.chat`），子进程不注入。
6. **`oneShot` / `duplex` 的请求体不读不改**（读一次就没了）。
7. 多模态请求里只改 `type == "text"` 的 part，图片/文件部分原样保留。

---

## 7. 目录结构

```
app/src/main/java/com/hook/deepseek/
├── core/                      纯逻辑，不依赖 Xposed，可单测
│   ├── json/Json.kt           保序 JSON 扫描器 + 定点替换
│   ├── prompt/                变换器链、请求/响应改写、结构校验
│   └── config/HookConfig.kt   配置模型 + JSON 序列化
├── engine/                    注入目标进程后执行
│   ├── OkHttpBridge.kt        反射式 OkHttp/Okio 访问层
│   ├── RequestLayer.kt        第一层
│   ├── ResponseLayer.kt       第二层
│   ├── ChainGuardLayer.kt     第三层
│   ├── PinnerBypass.kt        证书固定绕过
│   ├── conceal/Conceal.kt     环境隐藏
│   ├── config/ConfigClient.kt 跨进程配置读取
│   └── util/                  反射、日志、后台线程、Context
├── xapi/XHookApi.kt           与具体 Xposed API 解耦的抽象
├── ui/                        模块 App：配置界面 + 配置 Provider
├── legacy/…/ModuleEntry.kt    legacy 入口（assets/xposed_init）
└── modern/…/ModuleEntry.kt    libxposed 入口（META-INF/xposed/java_init.list）
```

详细设计说明见 `docs/ARCHITECTURE.md`。

---

## 8. 合规与风险边界

* 本工程面向自有设备上的安全研究与逆向工程学习，**不构成对 DeepSeek 服务条款的规避建议**。
* 对第三方客户端做请求/响应改写可能违反其用户协议，并触发账号风控。
* SSL Pinning 绕过与 root 隐藏只应限于**授权测试环境**；未经授权对生产服务做流量篡改，
  可能触及《计算机信息系统安全保护条例》等相关规定。
* 模块代码不应分发用于绕过付费功能或批量自动化滥用。
* 改写日志默认脱敏，不记录请求/响应正文。
