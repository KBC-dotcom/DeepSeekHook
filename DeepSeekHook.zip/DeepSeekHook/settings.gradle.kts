pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // 旧版 Xposed API (de.robv.android.xposed:api:82)
        maven { url = uri("https://api.xposed.info/") }
        // libxposed 新版 API (io.github.libxposed:api) 已在 Maven Central
    }
}

rootProject.name = "DeepSeekHook"
include(":app")
